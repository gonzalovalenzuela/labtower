# Changelog

## 2.1.8a — 2026-11-06

- **Nuevo:** Uptime Monitor (`/uptime/`, servicio `labtower-uptime`). Revisa servicios por HTTP(S), TCP y DNS cada cierto intervalo (60 s por defecto, de 20 s a 1 h). HTTP(S): código de respuesta esperado (200-399 por defecto) y palabra clave opcional. DNS: registro A o AAAA, con el resolvedor del servidor o uno dado, e IP esperada opcional.
- **Nuevo:** Uptime Monitor: un servicio se marca caído después de 3 fallos seguidos (configurable de 1 a 6); mientras tanto queda «Pendiente».
- **Nuevo:** Uptime Monitor: barra con las últimas 50 revisiones, disponibilidad de 24 h, 7 y 30 días, y gráfico del tiempo de respuesta con rangos (1 h, 1 día, 1 semana, 1 mes, todo) y comparación con el periodo anterior, igual que los demás módulos.
- **Nuevo:** Uptime Monitor: vencimiento de certificados HTTPS, con aviso 14 días antes por defecto. «No verificar el certificado» acepta un certificado autofirmado (Proxmox, NAS) y sigue revisando el vencimiento.
- **Nuevo:** Resumen: tarjeta de Uptime (servicios arriba, caídos y certificados por vencer) y eventos en la línea de tiempo: caído, vuelve a estar arriba, certificado por vencer y certificado vencido.
- **Nuevo:** permiso «Uptime Monitor» por usuario en el Admin Panel. Al actualizar, quien administra WOL queda como administrador y el resto con solo lectura. El módulo va en el grupo Red del menú y en la página de inicio, entra en los respaldos y se puede apagar con `labtower-modules`.
- **Arreglo:** todos los servicios: una petición HEAD o mal formada dejaba un error en el journal y cortaba la conexión sin respuesta. Ahora responden 501.

## 2.1.8 — 2026-11-05

- **Cambio:** los servicios se llaman todos `labtower-<módulo>`: labtower-wol, labtower-auth, labtower-net, labtower-pve, labtower-nas, labtower-dns, labtower-wan y labtower-vpn (labtower-ups y labtower-overview no cambian). Al actualizar, el instalador quita los nombres viejos; los datos no se tocan. Ejemplo: `journalctl -u labtower-wan`.
- **Mejora:** nuevo permiso por usuario, «Ver números de serie» (sí/no), para UPS, NAS, discos y nodos de Proxmox. Sin él, el servidor no envía esos datos al navegador. Los usuarios nuevos lo traen en «no»; al actualizar lo conservan los administradores de WOL o UPS.
- **Mejora:** Proxmox Monitor: al hacer clic en el nombre de un nodo se abre su detalle completo, con gráficos por rango. Si el nodo tiene el add-on PVE mods, muestra las temperaturas y los ventiladores agrupados como en Proxmox: estado térmico de la CPU por núcleo (con máximo y crítico), temperaturas NVMe por modelo, otras temperaturas y ventiladores en RPM, además de «Sensor Mod Version» e «Information». Requiere PVE mods instalado en cada nodo (ver README).
- **Arreglo:** Proxmox Monitor: los servicios apagados a propósito (`syslog`, `systemd-timesyncd`…) ya no aparecen como «dead». Se muestra un resumen y solo se marcan en rojo los que deberían estar corriendo o fallaron.
- **Mejora:** WAN Monitor: gráfico de las pruebas de velocidad con rangos (1 h, 1 día, 1 semana, 1 mes, todo). El período de las pruebas se fija en minutos u horas (mínimo 5 minutos); con menos de 30 minutos aparece una advertencia: puede saturar el enlace rápidamente. Lo que ya tenías guardado en horas se convierte solo.
- **Arreglo:** WAN Monitor: ya no consulta el DNS cada vez que lee su configuración. Antes mandaba al DNS de la red una consulta a api.ipify.org y dos a speed.cloudflare.com cada pocos segundos (decenas de miles al día). Ahora el nombre se resuelve al guardar y una vez antes de conectarse.
- **Mejora:** Net Monitor: el gráfico de temperatura de los switches tiene rangos (1 h, 1 día, 1 semana, 1 mes, todo).
- **Mejora:** DNS Monitor: «Consultas por hora» con rangos (1 día, 1 semana, 1 mes, todo) y un gráfico nuevo de actividad por cliente (Pi-hole).
- **Arreglo:** la tarjeta de IP ya no ofrece Net Monitor para esta misma máquina (127.0.0.1, ::1, localhost), por ejemplo en los clientes de UPS Monitor.
- **Mejora:** la versión de LabTower aparece en el pie de todas las páginas, incluido el kiosko, el inicio y el cambio de contraseña.
- **Mejora:** Resumen: el campo del código de verificación (2FA) del inicio de sesión queda bajo la contraseña y desaparece al iniciar sesión; se quitó la fila de botones de módulos (queda el filtro «Solo con problemas»); en el menú clásico el título lleva el icono de LabTower, la tira de módulos cabe en una línea con nombres cortos (UPS, Net, WOL, Admin) y la barra superior queda alineada con las tarjetas; en el kiosko, «N connected» de VPN Monitor queda en una sola línea.
- **Mejora:** en el móvil, la barra inferior de todas las secciones tiene el botón «Salir».
- **Cambio:** WOL Console: se quitó «Export JSON» del menú Acciones y el «v2» bajo el nombre.
- **Arreglo:** instalador: al actualizar ya no devuelve todos los datos al usuario «labtower» (mostraba «data of a previous installation handed back to labtower» en cada actualización). Eso solo ocurre tras un purge.
- **Arreglo:** auth, labtower-resetpw y Net Monitor cargan en Python 3.9, la versión mínima del paquete (anotaciones «X | None»). Un test nuevo revisa el código empaquetado con la gramática de 3.9.
- **Arreglo:** el estado del respaldo SFTP quedaba vacío cada hora en servidores con el registro en RAM (DietPi vacía /var/log). El estado, el resultado de la verificación y el registro de restauraciones ahora se guardan en /var/lib/labtower/state y se migran solos al actualizar. Si el archivo de estado está vacío, `labtower-sftp-backup status` y el panel lo tratan como «aún no corrió» en lugar de «ilegible».
- **Mejora:** la cookie de sesión guardada de los switches se crea ya con permiso 600.
- **Mejora:** README: instalación en una VM o en una Raspberry Pi, y requisito de PVE mods para el detalle de nodos de Proxmox.

## 2.1.7 — 2026-11-04

- **Nuevo:** navegación unificada. Barra superior con logo (Inicio), grupo actual y selector de módulo con su estado (forma y texto, no solo color), o menú lateral clásico; un asistente permite elegir la primera vez y «Tipo de menú» lo cambia después. En móvil hay barra inferior. Un aviso con enlaces aparece bajo la barra del módulo cuando algún módulo tiene avisos o fallas. El menú muestra solo los módulos con permiso y los que el admin no apagó.
- **Nuevo:** el admin puede deshabilitar los módulos que no usa (Admin Panel → Módulos, o `sudo labtower-modules disable|enable <módulo>`). Desaparecen de menús, inicio y Resumen, no cuentan en la salud y siguen apagados tras reinicios, actualizaciones y restauraciones; sus datos se conservan.
- **Nuevo:** Resumen: fila de chips de estado por módulo (● ok, ▲ aviso, ■ falla, con el número de avisos); un clic va a la tarjeta y Ctrl/⌘+clic abre el módulo. «Solo con problemas» oculta las tarjetas sanas y se recuerda.
- **Nuevo:** Proxmox Monitor: capacidad y salud del cluster (días hasta llenarse, prueba N-1, HA, replicación, tareas fallidas, Ceph, datos por nodo, cambios de estado de invitados y bloqueos). El README indica los privilegios que necesita el token de API.
- **Nuevo:** UPS Monitor: estado detallado (banderas), alarmas y beeper, calidad de la red eléctrica y margen de apagado.
- **Nuevo:** NAS Monitor: días hasta llenarse cada volumen, temperatura máxima y promedio de 24 h por disco, enlace caído y errores de cada puerto de red, y eventos en el Resumen (actualización disponible, ventiladores, disco caliente, enlace caído, errores de red, reinicio).
- **Nuevo:** WAN Monitor: calidad por destino, percentiles de latencia, velocidad frente al plan, disponibilidad y MTBF, eventos de calidad sostenida, historial de IP pública (con año, sin límite de retención; recupera cambios anteriores desde los eventos) y traceroute automático al abrirse cada corte. La fecha desde la que se conoce la IP se edita en Settings (dd-mm-aaaa), y la tarjeta Connection y el panel lateral muestran los días desde el último cambio. El paquete `traceroute` pasa a ser recomendado.
- **Nuevo:** Net Monitor: cambio de MAC en una IP, dispositivos sin revisar, historial de conectividad por equipo, equipos vigilados con latencia, puertos nuevos y marca de equipo inestable.
- **Nuevo:** DNS Monitor: salud de los DNS de salida (sondeo cada 60 s, con alerta y evento en el Resumen) y prueba de resolución que compara tu DNS con un resolutor externo y detecta nombres bloqueados.
- **Nuevo:** WOL Console: estado en vivo de cada equipo (ping desde el servidor) y confirmación de encendido: avisa «encendió (N s)» o que no respondió en 3 minutos.
- **Mejora:** el VPN Monitor guarda la última lectura de cada servidor y la muestra de inmediato tras reiniciar («Lectura anterior, actualizando…»); las lecturas de más de 5 s quedan en el log (`slow read`). El Resumen muestra solo la cantidad de clientes VPN conectados.
- **Mejora:** barra común en todos los módulos y en el Resumen (idioma, tema, reloj, usuario, salir, 24H y «Tipo de menú»), de ancho completo; con la barra superior suben a la barra global y la barra del módulo se oculta si no le queda nada propio. Los botones de acción (Scan network, Settings, Wake All) comparten un solo aspecto.
- **Mejora:** Net Monitor: auto-scan, limpieza de equipos sin conexión, SNMP y Pi-hole pasan a una ventana «Settings», como en WAN Monitor.
- **Mejora:** una sola escala de texto en todos los módulos: cabecera de tabla 11 px / 600, celda 13 px, título de tarjeta 12 px.
- **Mejora:** Proxmox: «Días hasta llenarse» distingue «Reuniendo historial (X de 2 días necesarios)» de «No crece».
- **Mejora:** el ícono de la barra superior vuelve a ser el original de LabTower; Admin Panel, Net, Proxmox, NAS, DNS, WAN y VPN ahora tienen ícono en la pestaña del navegador.
- **Seguridad:** al restablecer la contraseña de otra cuenta, el cambio en el siguiente inicio de sesión es obligatorio, y los usuarios nuevos lo llevan marcado; cambiar niveles de permiso pide la contraseña actual.
- **Seguridad:** las URLs https de WAN no pueden apuntar a esta máquina ni a direcciones link-local; NUT rechaza 0.0.0.0 y link-local; el sondeo de DNS de salida solo usa el puerto 53 o puertos altos; el servicio de autenticación limita los eventos y registros que cada módulo puede escribir, y el módulo WAN lee solo sus propios eventos.
- **Arreglo:** Net Monitor: Pi-hole dejaba de conectar hasta pulsar «Guardar» cuando renovaba o regeneraba su certificado propio. Si el certificado fijado venció, o el nuevo trae el mismo sujeto y emisor, se fija el nuevo (queda en el registro y en los eventos); con otra identidad sigue rechazado. Si falla sin nombres conocidos reintenta al minuto, y el panel muestra el error de la consulta de dispositivos.
- **Arreglo:** Net Monitor: guardar los ajustes de Pi-hole con la contraseña en blanco borraba la contraseña guardada y Pi-hole quedaba desconectado sin avisar. Ahora una contraseña vacía conserva la guardada (el campo lo indica) y, si no hay ninguna guardada, pide escribirla.
- **Arreglo:** Net Monitor: el switch ZX quedaba «unreachable» tras cada reinicio o actualización. La sesión web del switch se guarda (modo 600) y se reutiliza, y tras varios rechazos seguidos se espera más entre intentos.
- **Arreglo:** Net Monitor: guardar OUI o SNMP podía borrar huellas de Pi-hole recién fijadas; el grupo de un equipo se perdía en cada reescaneo.
- **Arreglo:** DNS Monitor: el texto de la prueba de resolución se borraba cada 5 s al redibujarse la página y el test no se ejecutaba.
- **Arreglo:** en el modo «barra superior» se perdía el botón «Ajustes» de WAN Monitor; el aviso «Attention» quedaba encima de la barra del módulo y «Scan network» / «Settings» al centro.
- **Arreglo:** un POST sin cuerpo ya no devuelve 400 en Net, NUT, Proxmox, NAS, VPN, WOL, Resumen y Panel; el escape de HTML de Net, WOL y Panel cubre también la comilla simple.

## 2.1.6p — 2026-11-04

- **Arreglo:** Net Monitor: guardar los ajustes de Pi-hole con la contraseña en blanco borraba la contraseña guardada y Pi-hole quedaba desconectado sin avisar. Ahora una contraseña vacía conserva la guardada (el campo lo indica) y, si no hay ninguna guardada, pide escribirla.
- **Mejora:** WAN Monitor: la tarjeta Connection y el panel lateral muestran los días desde el último cambio de IP en lugar de la fecha; la fecha exacta queda en el historial.

## 2.1.6o — 2026-11-04

- **Mejora:** WAN Monitor: la fecha desde la que se conoce la IP pública se edita en Settings (formato dd-mm-aaaa) y no desde la tarjeta del historial.
- **Mejora:** WAN Monitor: el historial de IP pública no se borra nunca (antes se conservaban 30 días, salvo la IP actual); la tarjeta muestra los 20 cambios más recientes.

## 2.1.6n — 2026-11-04

- **Arreglo:** Net Monitor: el switch ZX quedaba «unreachable» tras cada reinicio o actualización (el switch no entregaba una sesión nueva mientras la anterior seguía viva). La sesión web se guarda (modo 600) y se reutiliza; tras varios rechazos seguidos se espera más entre intentos.
- **Arreglo:** Net Monitor: Pi-hole dejaba de conectar cuando regeneraba su certificado propio. Si el nuevo trae el mismo sujeto y emisor se acepta, se vuelve a fijar y queda un evento; con otra identidad sigue rechazado. Si falla sin nombres conocidos reintenta al minuto, y el panel muestra el error de la consulta de dispositivos.
- **Arreglo:** WAN Monitor: el historial de IP pública muestra el año y el registro más antiguo tiene un selector de fecha (administradores) para fijar desde cuándo se conoce. Una fecha editada a mano en `state.json` prevalece sobre la de la base de datos.
- **Arreglo:** Resumen: la barra superior ocupa todo el ancho como en los demás módulos y el título ya no se repite; la tira de módulos salta de línea entre grupos.
- **Arreglo:** el aviso «Attention» queda bajo la barra del módulo, alineado con el contenido, en vez de encima; en Net Monitor «Scan network» y «Settings» quedan junto al título.

## 2.1.6m — 2026-11-04

- **Nuevo:** Resumen: fila de chips de estado por módulo (● ok, ▲ aviso, ■ falla, con el número de avisos). Un clic va a la tarjeta; Ctrl/⌘+clic abre el módulo. «Solo con problemas» oculta las tarjetas sanas y se recuerda.
- **Mejora:** Resumen: usa la misma barra común que los demás módulos (idioma, tema, reloj, usuario, salir y 24H); con el menú de barra superior suben a la barra global.
- **Mejora:** Net Monitor: auto-scan, limpieza de equipos sin conexión, SNMP y Pi-hole pasan a una ventana «Settings», como en WAN Monitor. «Scan network» y «Settings» suben a la barra superior.
- **Mejora:** los botones de acción de los módulos (Scan network, Settings, Wake All) comparten un solo aspecto y suben a la barra global.
- **Mejora:** una sola escala de texto en todos los módulos: cabecera de tabla 11 px / 600, celda 13 px, título de tarjeta 12 px, ítems del menú de WOL como los demás.
- **Mejora:** Proxmox: «Días hasta llenarse» distingue «Reuniendo historial (X de 2 días necesarios)» de «No crece».
- **Arreglo:** DNS Monitor: el texto de la prueba de resolución se borraba cada 5 s al redibujarse la página y el test no se ejecutaba.
- **Arreglo:** WAN Monitor: la IP actual desaparecía del historial al ser más antigua que 30 días.

## 2.1.6l — 2026-11-03

- **Arreglo:** en el modo de menú «barra superior» se perdía el botón «Ajustes» de WAN Monitor (la barra del módulo quedaba vacía u oculta). Ahora el botón vive fuera del texto que esa barra oculta y la barra se vuelve a evaluar cuando le aparecen botones después de cargar los datos. Se revisaron todos los módulos en 4 tamaños y no se perdía ningún otro control.
- **Arreglo:** WAN Monitor: el historial de IP pública solo contaba desde la instalación de la tabla nueva. Al iniciar recupera los cambios anteriores desde el registro de eventos (los que sigan dentro de sus 30 días / 300 eventos); para eso el módulo WAN puede leer solo sus propios eventos.
- **Arreglo:** Net Monitor: Pi-hole dejaba de conectar hasta pulsar «Guardar» sin cambiar nada. La huella fijada (TOFU) se rechazaba cuando Pi-hole renovaba su certificado. Ahora, si el certificado fijado ya venció y el nuevo está vigente, se fija el nuevo automáticamente (queda en el registro y en los eventos); si el fijado sigue vigente el cambio se sigue rechazando, y el mensaje de error ya no se corta a 80 caracteres e indica qué hacer.
- **Arreglo:** Net Monitor: guardar OUI o SNMP podía borrar huellas de Pi-hole recién fijadas (escritura de configuración sin bloqueo).

## 2.1.6k — 2026-11-03

- **Nuevo:** WOL Console: estado en vivo de cada equipo (ping desde el servidor) y confirmación de encendido: tras enviar el paquete avisa «encendió (N s)» o que no respondió en 3 minutos.
- **Nuevo:** WAN Monitor: historial de cambios de IP pública y traceroute automático al abrirse cada corte, visible desde la tabla de cortes (el paquete `traceroute` pasa a ser recomendado).
- **Nuevo:** DNS Monitor: salud de los DNS de salida (sondeo directo cada 60 s, con alerta y evento en el Resumen) y prueba de resolución que compara tu DNS con un resolutor externo y detecta nombres bloqueados.
- **Arreglo:** el esquema de métricas declaraba dos veces la tabla de destinos del WAN.
- **Seguridad:** el sondeo de DNS de salida solo consulta el puerto 53 o puertos altos; el historial de IP pública se inicializa con la IP ya conocida.
- **Arreglo:** avisos de pyflakes en las pruebas (importaciones y variables sin uso).

## 2.1.6j — 2026-11-03

- **Nuevo:** Proxmox Monitor: capacidad y salud del cluster (días hasta llenarse, prueba N-1, HA, replicación, tareas fallidas, Ceph, datos de cada nodo, cambios de estado de invitados y bloqueos). El README indica ahora los privilegios que necesita el token de API.
- **Nuevo:** UPS Monitor: estado detallado (banderas), alarmas y beeper, calidad de la red eléctrica y margen de apagado.
- **Nuevo:** WAN Monitor: calidad por destino, percentiles de latencia, velocidad frente al plan, disponibilidad y MTBF, y eventos de calidad sostenida.
- **Nuevo:** Net Monitor: cambio de MAC en una IP, dispositivos sin revisar, historial de conectividad por equipo, equipos vigilados con latencia, puertos nuevos y marca de equipo inestable.
- **Seguridad:** al restablecer la contraseña de otra cuenta, el cambio en el siguiente inicio de sesión es siempre obligatorio, y los usuarios nuevos lo llevan marcado por defecto.
- **Seguridad:** cambiar niveles de permiso de un usuario pide la contraseña actual.
- **Seguridad:** las URLs https de WAN no pueden apuntar a esta máquina ni a direcciones link-local; NUT rechaza 0.0.0.0 y link-local; el servicio de autenticación limita los eventos y registros que cada módulo puede escribir.
- **Arreglo:** un POST sin cuerpo ya no devuelve 400 en Net, NUT, Proxmox, NAS, VPN, WOL, Resumen y Panel.
- **Arreglo:** el grupo de un equipo en Net Monitor se perdía en cada reescaneo.
- **Arreglo:** el escape de HTML de Net, WOL y Panel ahora también cubre la comilla simple.

## 2.1.6i — 2026-11-03

- **Nuevo:** NAS Monitor muestra cuántos días faltan para que se llene cada volumen (según su crecimiento de los últimos 14 días, con aviso a 30 días y crítico a 7) y la temperatura máxima y promedio de 24 horas de cada disco.
- **Nuevo:** NAS Monitor muestra el enlace caído y los errores de cada puerto de red (Synology) y anota en la línea de tiempo del Resumen: actualización disponible, falla de ventiladores, disco muy caliente, enlace de red caído, errores de red y reinicio del NAS.
- **Arreglo:** Admin Panel, Net Monitor, Proxmox, NAS, DNS, WAN y VPN no tenían ícono en la pestaña del navegador; ahora todas las pantallas lo tienen.

## 2.1.6h — 2026-11-03

- **Arreglo:** en WOL Console el reloj también sube a la barra superior junto al resto de las opciones.

## 2.1.6g — 2026-11-03

- **Mejora:** la barra del módulo se fusionó con la barra superior: idioma, tema, reloj, usuario y «salir» (y «Tipo de menú») ahora están en una sola barra arriba a la derecha, junto al selector de módulo. Si a la barra del módulo no le queda nada propio (por ejemplo en el Admin Panel y en WAN Monitor), se oculta y el contenido sube. Los módulos con controles propios (por ejemplo Net Monitor con el escaneo) los conservan en una barra más delgada.

## 2.1.6f — 2026-11-03

- **Mejora:** «Tipo de menú» pasó a la barra de opciones de cada pantalla, junto al idioma y el tema.
- **Mejora:** con la barra superior se quitó el encabezado repetido del panel lateral y, si el panel no tiene listas propias (Admin Panel, WAN Monitor), se oculta para usar todo el ancho; en el Admin Panel el usuario y «salir» pasan a la barra superior.

## 2.1.6e — 2026-11-03

- **Mejora:** el ícono de la barra superior vuelve a ser el original de LabTower.
- **Mejora:** si algún módulo tiene avisos o fallas, un aviso con enlaces aparece arriba del contenido, bajo el menú, en todos los módulos.
- **Mejora:** el Resumen muestra solo la cantidad de clientes conectados en VPN; el detalle queda dentro del VPN Monitor.
- **Nuevo:** asistente para elegir el tipo de menú, la primera vez que entras: barra superior con selector (nuevo) o menú lateral clásico. Se puede cambiar después en «Tipo de menú…». Se guarda en el navegador.

## 2.1.6d — 2026-11-03

- **Mejora:** nueva navegación. En escritorio y iPad hay una barra superior con el logo (Inicio), el grupo actual y un selector del módulo (con su estado) que abre un panel con todos los módulos agrupados; se cierra con Esc o al hacer clic fuera. En móvil hay una barra inferior (Inicio, Resumen, Módulos, Opciones) y los módulos se eligen en una hoja desde abajo. El estado se indica con forma y texto, no solo con color. Se oculta en modo kiosco. El menú lateral de cada módulo queda solo con lo propio del módulo.

## 2.1.6c — 2026-11-02

- **Mejora:** navegación unificada. Todos los módulos comparten el mismo menú lateral, con «Inicio» y «Resumen» arriba y los módulos agrupados (Energía y servidores, Red, Herramientas, Sistema), el módulo actual resaltado y el estado de cada uno (verde, amarillo, rojo) junto al nombre. Solo aparecen los módulos a los que tienes permiso y los que el admin no apagó. El menú ya no se reordena arrastrando, así que el orden es el mismo en todas las pantallas y en la portada.
- **Mejora:** el Resumen tiene la misma navegación como barra superior (se oculta en modo kiosco) en lugar del botón «Inicio», y la portada agrupa las tarjetas igual que el menú.

## 2.1.6b — 2026-11-02

- **Mejora:** el VPN Monitor guarda la última lectura de cada servidor y la muestra de inmediato tras reiniciar (marcada «Lectura anterior, actualizando…») en vez de quedar vacío hasta que responda el SSH. Las lecturas que tardan más de 5 s se anotan en el log (`slow read`) para encontrar el servidor lento.

## 2.1.6a — 2026-11-02

- **Nuevo:** el admin puede deshabilitar los módulos que no usa (Admin Panel → Módulos, o `sudo labtower-modules disable|enable <módulo>`). El módulo se detiene y desaparece de los menús, del inicio y del Resumen, no cuenta en la salud, y sigue apagado tras reinicios, actualizaciones y restauraciones de respaldo. Sus datos se conservan. Solo lo cambia quien administra todos los módulos; queda en la auditoría.

## 2.1.6 — 2026-11-02

- **Nuevo:** VPN Monitor (`/vpn/`, puerto 8089): quién está conectado a Tailscale, OpenVPN y WireGuard, desde cuándo, con qué dirección y cuánto tráfico.
  - Tailscale se lee por su API (clave de solo lectura). OpenVPN (archivo de estado, versiones 1, 2 y 3) y WireGuard (`wg show all dump`) se leen por SSH, de solo lectura, con una llave propia que LabTower genera y que se recomienda restringir en `authorized_keys` con `command="…"`.
  - La opción «Ejecutar con sudo» sirve para servidores donde el archivo de estado o `wg show` son solo de root (por ejemplo Synology). Usa `sudo -n` y solo con los dos comandos fijos.
  - Los peers de WireGuard se nombran con alias por clave pública.
  - Incluye sesiones recientes, avisos de conexión y desconexión en el Resumen, tarjeta en el Resumen, permiso propio (Admin Panel → usuarios), servicio con usuario propio y respaldo de `vpn.json` y `state.json`. La llave SSH no se respalda: tras restaurar, créala de nuevo y vuelve a instalarla en el servidor VPN.
- **Nuevo:** `sudo labtower-resetpw [usuario]` para recuperar el acceso desde la consola: genera una contraseña aleatoria (cambio obligatorio en el próximo inicio), cierra las sesiones de ese usuario, quita su bloqueo por intentos y lo anota en la auditoría. Opciones: `--ask` (tú escribes la contraseña), `--disable-2fa` (perdiste el teléfono) y `--list`.
- **Mejora:** la portada muestra el estado de cada módulo junto a la flecha de su tarjeta, con el `/api/health` público de cada uno: verde «activo», amarillo «con avisos», rojo «con fallas» y gris «sin respuesta». Antes solo había dos indicadores (WOL y NUT) y «activo» solo significaba que el servicio contestaba.
- **Mejora:** WAN Monitor: ajustes «Bajada contratada» y «Subida contratada» (Mb/s). La tarjeta de velocidad muestra el porcentaje entregado en la última prueba y su promedio de 7 días (verde desde 90 %, naranja desde 70 %, rojo bajo eso).
- **Mejora:** NAS Monitor: los umbrales de espacio de los volúmenes se configuran por NAS (Editar NAS → «Aviso de volumen» y «Crítico de volumen», por defecto 90 % / 95 %). Antes las alertas usaban 90/95 pero los colores de la página NAS y del Resumen usaban 80/90 fijos, y un volumen al 84 % salía en naranja/rojo sin alerta.
- **Mejora:** Proxmox Monitor: botón «Expandir todo / Contraer todo» en Diagnóstico del cluster.
- **Quitado:** tarjeta «Monitores sugeridos» del Resumen (demasiados falsos positivos).
- **Fix:** en un CT de Proxmox, restaurar un respaldo desde el Admin Panel fallaba con «The "no new privileges" flag is set». El servicio `admin-panel` ahora se instala sin las opciones que lo activan; en una VM no cambia nada.
- **Fix:** Admin Panel, subir respaldo: el selector aceptaba solo `.gz`, pero los respaldos del panel salen cifrados (`.gpg`). Ahora acepta también `.gpg`.

## 2.1.5 — 2026-11-02

Reúne todos los cambios desde 2.1.4 (builds 2.1.4a a 2.1.4v).

**Resumen**
- **Nueva Funcionalidad:** Búsqueda global en la barra superior (también con la tecla `/`). Busca equipos de Net Monitor, UPS, VMs y contenedores de Proxmox, NAS, servidores DNS y equipos de Wake-on-LAN. Solo muestra lo que cada usuario tiene permiso de ver.
- **Nueva Funcionalidad:** Tarjeta «Reglas de alerta»: los administradores definen umbrales sobre las métricas del servidor, UPS, NAS, Proxmox, DNS e internet (por ejemplo, «temperatura del servidor > 65 °C» o «batería del UPS < 50 %»), como aviso o crítico. Las reglas que se cumplen aparecen en el panel de atención y en el estado general. Se evalúan mientras el Resumen está abierto.
- **Nueva Funcionalidad:** Tarjeta «Monitores sugeridos»: si Net Monitor ve un equipo con puertos típicos de un servicio que LabTower puede monitorear (Proxmox, servidor UPS, Pi-hole o AdGuard Home, Synology) y aún no está configurado, lo sugiere con un enlace al módulo. Solo la ven los administradores de ese módulo y cada sugerencia se puede descartar.
- **Nueva Funcionalidad:** Se puede pausar y reanudar el bloqueo de Pi-hole / AdGuard desde la tarjeta DNS (5 min, 30 min, 1 hora o hasta reanudar). Requiere nivel «ejecutar» en DNS Monitor.
- **Mejora:** En modo kiosko no se muestran los controles para pausar el bloqueo de Pi-hole.

**Gráficos (UPS, NAS, DNS, WAN y switches)**
- **Mejora:** Todos los gráficos de detalle se ven y funcionan igual: mismos colores, ejes, etiquetas de fecha y ventana con valores al pasar el mouse.
- **Nueva Funcionalidad:** Rango de 1 semana en UPS, NAS, DNS y WAN.
- **Nueva Funcionalidad:** Botón «vs anterior», que dibuja con línea punteada el período justo anterior para comparar.
- **Nueva Funcionalidad:** Los eventos importantes (cortes de energía, cambios de IP, caídas) aparecen como marcas sobre el gráfico del módulo correspondiente.

**Net Monitor**
- **Nueva Funcionalidad:** Las VM y contenedores de Proxmox se reconocen en la tabla de equipos: insignia «VM 100» / «CT 200» junto al nombre, detalle con la VM/CT correspondiente y búsqueda por «proxmox», «vm», «ct» o número. Se cruza por MAC, luego por IP y, si no hay ninguna, por nombre idéntico.
- **Nueva Funcionalidad:** Opción «Quitar sin conexión tras N días» para eliminar solos los equipos que dejaron de responder (0 = nunca). Solo la ven y la cambian los administradores.
- **Nueva Funcionalidad:** Switch Monitor: los switches se listan en la barra lateral y se puede elegir uno para verlo solo.
- **Nueva Funcionalidad:** Switch Monitor: la velocidad de cada puerto tiene color (10G, 2.5G, 1G, 100M, 10M) en el panel, en la tabla y en una leyenda.
- **Nueva Funcionalidad:** El panel de Pi-hole muestra cuántos dispositivos, concesiones DHCP y registros de DNS local leyó, y avisa si alguno no se pudo leer.
- **Mejora:** Las tarjetas «Hosts descubiertos», «Online» y «Offline» se pueden tocar y filtran la tabla igual que los botones; tocar de nuevo la activa vuelve a mostrar todos.
- **Mejora:** Los nombres de Pi-hole incluyen los registros de «Local DNS» y las concesiones DHCP, con prioridad sobre el DNS inverso. Se actualizan cada 5 minutos (antes 30) y al empezar cada escaneo; si Pi-hole no responde, se conservan los que ya había.
- **Mejora:** Los nombres también se piden directo al DNS de Pi-hole (puerto 53), sin contraseña ni API, así aparecen aunque la contraseña de aplicación no pueda leer la configuración.
- **Fix:** Los equipos apagados o sin respuesta (por ejemplo la interfaz AMT de un servidor apagado) no recibían nombre de Pi-hole ni del DNS; ahora sí.
- **Fix:** La purga de equipos offline no borra nada si en el escaneo no respondió ningún equipo (por ejemplo, si el servidor perdió la red).
- **Seguridad:** Los nombres que vienen de Pi-hole o del DNS se limpian de caracteres de control y se limitan a 80 caracteres. La consulta directa al DNS aplica la misma regla anti-SSRF que la API de Pi-hole.

**Proxmox Monitor**
- **Nueva Funcionalidad:** Click en el nombre de una VM o contenedor lleva a su detalle en Net Monitor (como en UPS Monitor), con tarjeta de datos al pasar el mouse.
- **Nueva Funcionalidad:** Lee la MAC y las IP de cada VM/CT (fijas del contenedor, agente de invitado en las VM, interfaz del contenedor), cada 5 minutos, en `/api/guests`.
- **Nueva Funcionalidad:** Botón «Ocultar detenidas» para esconder las VM y contenedores apagados (se recuerda en el navegador).
- **Mejora:** Los días para marcar un respaldo como viejo se configuran por cluster (solo administradores). Por defecto son 7 días (antes 36 horas).
- **Mejora:** Los nombres de las VM y contenedores ya no se cortan; las métricas pasan a una segunda línea bajo el nombre.
- **Fix:** Corregido un error que impedía cargar la página.

**UPS Monitor**
- **Mejora:** Los equipos conectados al UPS muestran el nombre que Net Monitor conoce; si no tiene, la IP.
- **Mejora:** Si la batería tiene menos de 1 año, la edad se muestra en meses.
- **Mejora de rendimiento:** El estado de envejecimiento de la batería se calcula en segundo plano (antes frenaba la página más de un segundo) y se guardan unos segundos las pruebas de batería y la fecha de cambio para no leer disco y base de datos en cada consulta.

**WAN Monitor**
- **Mejora:** El aviso de cambio de IP pública indica la IP anterior, dura 24 horas y queda en la línea de tiempo del Resumen. La IP pública aparece también en la barra lateral.

**Admin Panel**
- **Nueva Funcionalidad:** La tabla de usuarios tiene la columna «Última conexión».
- **Fix:** «Última conexión» ya no sale vacía para quien tiene una sesión abierta.
- **Mejora:** El aviso de versión nueva muestra los comandos para actualizar (`wget` y `sudo apt install`) con un botón para copiarlos.

**Instalador**
- **Mejora:** Al terminar ya no recomienda activar el HTTPS si ya está activado; muestra que está habilitado.

**Interno**
- **Mejora:** Scripts de respaldo, HTTPS e instalación sin avisos de `shellcheck` (incluye una protección para que una variable vacía nunca borre `/etc`) y se quitó código que ya no se usaba. No cambia comportamientos.
- **Mejora:** Los escaneos de seguridad de GitHub (bandit y gitleaks) quedan en verde.

## 2.1.4 — 2026-10-30

- **Seguridad:** Autenticación en dos pasos (2FA). En Admin Panel → «Seguridad» se activa escaneando un código QR con cualquier app (Google Authenticator, Aegis, 1Password…); la clave escrita queda como alternativa. Se entregan 10 códigos de recuperación de un solo uso. Con 2FA activo, todos los formularios de acceso piden el código; cada código sirve una vez y los intentos fallidos cuentan para el bloqueo. Un admin puede restablecer el 2FA de otro usuario. El QR se genera dentro de LabTower, sin librerías ni internet.
- **Seguridad:** Registro de auditoría en Admin Panel: quién creó o eliminó usuarios, cambió permisos o contraseñas, activó o restableció 2FA, cerró sesiones, creó/descargó/restauró/eliminó respaldos, cambió la configuración del WAN Monitor o la fecha de una batería, y los bloqueos por intentos fallidos. Guarda las últimas 5.000 entradas y nunca contraseñas ni códigos.
- **Nueva Funcionalidad:** Aviso de versión nueva en Admin Panel: consulta las versiones publicadas en GitHub (solo estables) cada 12 horas como máximo y avisa con el enlace a las notas. Solo lee; no descarga ni instala. Se desactiva con `LABTOWER_UPDATE_CHECK=0` en `/etc/default/labtower`.

**WAN Monitor**
- **Nueva Funcionalidad:** Chequeo del router. Pregunta al router si su enlace WAN está arriba, para saber si un corte es de la red local o de la línea. Tipos: Huawei (WiFi AX3, Mesh y otros), OpenWrt, DD-WRT y TP-Link clásico. Los cortes se marcan como «Red local (LAN)», «Línea / proveedor (WAN)» o «Internet». Botón «Probar router» con el motivo exacto si falla. Solo lee; la clave se guarda en el servidor y nunca se muestra. Los TP-Link nuevos con inicio de sesión cifrado no se pueden consultar.
- **Nueva Funcionalidad:** Comparación con el router: en «Conexión» muestra cuánto tiempo lleva conectada la WAN según el router y cuántos cortes registró LabTower en ese período («2 aquí · 0 WAN»).

**UPS Monitor**
- **Nueva Funcionalidad:** Salud de la batería: autonomía ahora, a batería llena y con 50 % más de carga; edad de la batería y tendencia de capacidad (avisa si cae 20 % o más en 120 días).
- **Nueva Funcionalidad:** Fecha de cambio de la batería: botón ✎ junto a la edad para indicarla a mano (tiene prioridad sobre la del UPS).
- **Nueva Funcionalidad:** Edad de la batería: se leen `battery.date` y `battery.mfr.date` y se usa la más reciente creíble; una edad de más de 10 años se ignora (algunos UPS dejan la fecha de fábrica).
- **Nueva Funcionalidad:** Registro de autotests: los últimos 8; un test fallido avisa en el Resumen. «Último resultado» muestra la fecha y hora en que LabTower lo vio, y si el UPS vuelve a «No test initiated» (APC Back-UPS) se muestra el último resultado real. Los resultados se traducen al español.

**Proxmox Monitor**
- **Nueva Funcionalidad:** Diagnóstico del cluster: reinicios de nodos con línea de tiempo (marca los simultáneos), quórum de corosync, Ceph (OSD y avisos) y SMART de los discos, incluido «Unsafe Shutdowns» en NVMe.
- **Nueva Funcionalidad:** Respaldos (vzdump): último respaldo de cada VM/CT, antigüedad, tamaño y verificación; marca «Sin respaldo» o «Muy viejo» y lista las tareas fallidas. Se pueden **ignorar** VMs de prueba o templates, y marcar varias a la vez. El token necesita `Datastore.Audit` y `Sys.Audit` (rol `PVEAuditor`).

**NAS Monitor**
- **Nueva Funcionalidad:** Ahora también lee **TrueNAS** (25.04 o más nuevo) y **OpenMediaVault** (7 o más nuevo), solo lectura.

**Net Monitor / Switch Monitor**
- **Nueva Funcionalidad:** Errores CRC por puerto (cable o tarjeta de red), aviso de enlaces que rebotan y casilla «Avisar por puerto».

**Respaldo**
- **Nueva Funcionalidad:** `labtower-sftp-backup verify` y cron diario: comprueba en el storage que la copia más reciente existe, no está vacía y es reciente.

- **Mejora:** Los textos y la documentación ya no dicen «la Pi»: dicen «el servidor». «Raspberry Pi» queda solo en la fuente de poder, la temperatura y la lista de equipos compatibles.
- **Mejora:** La página de inicio ahora está en inglés y español, y la barra lateral dice «Resumen» en español.

- **Fix:** WOL Console: aviso «Net Monitor hosts file not readable» (los archivos compartidos quedaban en modo 600 en vez de 640).
- **Fix:** Proxmox: después de ignorar o dejar de ignorar una VM, la página podía mostrar el estado anterior hasta por 10 minutos.
- **Fix:** Textos sin traducir o mezclados entre idiomas en Net Monitor, Proxmox Monitor, WOL Console, NAS Monitor, WAN Monitor, Admin Panel y el Resumen; las fechas del UPS Monitor usan día/mes/año en español.
- **Fix:** NAS Monitor: el error de conexión ya no dice «esta Pi».

## 2.1.3 — 2026-10-29

Correcciones de la revisión de seguridad del código.

- **Seguridad:** Inicio de sesión: un ingreso correcto ya no reinicia el contador de intentos de la IP (antes, quien tenía una cuenta propia podía entrar entre intentos y adivinar otras claves sin límite). nginx aplica ahora el límite de intentos de login (10/min por IP) a **todos** los módulos, no solo al panel.
- **Seguridad:** Sesiones: cada sesión tiene un tope absoluto de vida desde su creación (14 días la normal, 30 «una semana», 90 «un mes», 400 «siempre»), aunque se siga usando.
- **Seguridad:** Contraseña en acciones críticas: crear un usuario, restablecer la clave de otro y restaurar o descargar un respaldo piden de nuevo la contraseña de la cuenta (con el mismo freno de intentos del login).
- **Seguridad:** Respaldos del panel: la descarga ahora sale **cifrada** (gpg, AES-256, el mismo formato del respaldo SFTP) con una frase de 12 o más caracteres que eliges; se puede subir un `.gpg` indicando la frase. Descargar sin cifrar exige marcarlo expresamente y queda en el registro. Crear un respaldo ya no lo descarga solo, y se elimina la ruta de descarga sin contraseña.
- **Seguridad:** Teleporter: el archivo de un respaldo (que puede venir de fuera) ya no lo abre root: `tar` y los validadores (JSON, SQLite) corren como el usuario sin privilegios, en una carpeta que ningún otro proceso de ese usuario puede alcanzar. `users.json` se valida también por su estructura (nombres, hashes y niveles) antes de restaurar, y al leerse cualquier nivel desconocido se trata como «none».
- **Seguridad:** Interfaz: los atributos `data-on-*` solo pueden invocar funciones registradas por cada módulo (lista cerrada) y no cualquier función global; los valores que se usan como nombre de clase (nivel de permiso, tipo de VM, etiqueta, bandera de puerto) se filtran.
- **Seguridad:** Servidores DNS con «Verificar el certificado TLS» desactivado: ya no se acepta cualquier certificado; se fija la huella en la primera conexión y un cambio se rechaza (guardar el servidor otra vez la borra).
- **Seguridad:** Destinos de conexión: Proxmox, NAS, DNS, Pi-hole y switches rechazan la propia máquina (loopback) y las direcciones de enlace local, también si un nombre resuelve a ellas, para que LabTower no sirva de puente hacia sus servicios internos.
- **Seguridad:** Entradas: las APIs rechazan con 400 (antes 500) un cuerpo JSON que no sea un objeto, JSON anidado en exceso o campos de tipo equivocado.
- **Seguridad:** nginx: el límite de 200 MB y la subida sin búfer valen solo para la ruta de subida de respaldos (el resto del panel mantiene 1 MB). La CSP ya no permite fuentes de Google (no se usaban).
- **Seguridad:** Aislamiento entre módulos (rediseño): cada servicio corre con su propio usuario del sistema (`labtower-<módulo>`), con su carpeta de datos privada (700) y su propio `metrics.db`; systemd solo le deja escribir esa carpeta. Los usuarios, sesiones, contadores y eventos pasan a `/var/lib/labtower/auth/`, que solo lee el servicio de autenticación (el Panel de administración, `labtower-auth`). Los demás módulos le consultan por un socket Unix (`/run/labtower/auth.sock`): comprobar una sesión, iniciar o cerrar sesión y anotar eventos, identificando a quien llama con el kernel (`SO_PEERCRED`). No hay ninguna operación que cree sesiones sin contraseña ni que lea usuarios, así que un módulo comprometido ya no puede falsificar sesiones, llevarse los hashes ni tocar los datos de otro módulo. El servicio limita conexiones simultáneas (64) y la duración de cada una (5 s); el cliente tiene un caché de sesiones acotado y un cortacircuito de 1 s si el servicio no responde (falla cerrado). `wol-console/devices.json` y `net-monitor/hosts.json` (que se leen entre sí) pasan a modo 640 de grupo, se leen como entrada no confiable (sin seguir enlaces, solo archivos regulares, máx. 4 MiB) y ya no hay una carpeta compartida.
- **Mejora:** Actualización a 2.1.3: el instalador crea los usuarios, borra los enlaces simbólicos que hubiera dentro de `/var/lib/labtower` (root no los sigue), reparte los archivos (`auth/`, cada módulo), parte el `metrics.db` común en uno por módulo (con un usuario sin privilegios; el original queda en `/var/backups/labtower/metrics.db.pre-isolation.*`) y reescribe las unidades systemd. Es idempotente. El usuario `labtower` queda solo como usuario sin datos con el que Teleporter abre respaldos no confiables. Los respaldos anteriores (con un solo `metrics.db`) se restauran partiéndolo por módulo.
- **Seguridad:** Teleporter: cada archivo restaurado queda a nombre del usuario de su módulo (modos 700/710 las carpetas, 600/640 los archivos); la instantánea de las bases SQLite la toma el dueño del archivo, no root; la regla `sudo` ahora es para `labtower-auth`.
- **Mejora:** Documentación: el README explica que las credenciales de los equipos se guardan legibles (permisos 600; usar cuentas de solo lectura), los destinos permitidos y el aislamiento entre módulos.

- **Fix:** Entradas con tipo equivocado: `POST /api/hosts/delete`, `/api/hosts/update` y `/api/scan` (Net Monitor), `/api/clusters` (Proxmox) y `/api/ping` (WOL) cortaban la conexión sin responder si el campo `ip` o `name` llegaba como lista, objeto o número; ahora contestan 400 como el resto.
- **Mejora:** Limpieza de código muerto: importaciones y variables sin uso en varios módulos, `${OLD:?}` en el `rm -rf` del instalador.
- **Fix:** Switch Monitor: «Actualizado hace …» muestra segundos enteros (antes salía, p. ej., «23.33152723312378 s»).
- **Fix:** Switch Monitor: el encabezado de la tabla de puertos dice «MBIT/S rx / tx» (antes, por las mayúsculas, se leía «MB/S» aunque los valores son megabits).
- **Fix:** Switch Monitor: las tarjetas de resumen pasan a otra fila cuando no caben (antes la etiqueta «Temperatura máx. (switch)» se salía de la tarjeta y los valores se partían), y la columna «Conectado a» de la tabla de puertos tiene un ancho mínimo mayor para que las filas no queden altísimas en pantallas angostas.

## 2.1.2 — 2026-10-28

- **Nueva Funcionalidad:** Switch Monitor: nueva pestaña en Net Monitor para monitorear switches administrables: ZX310S, HC-SWTGW218AS y cualquier switch SNMP v2c, como los TP-Link. Muestra el panel frontal con el estado de cada puerto (arriba, abajo, deshabilitado, errores nuevos, enlace entre switches, loop), velocidad, paquetes/s, errores, STP, temperatura, a qué equipo conocido está conectado cada puerto e historial de 1 año con gráficos. Los switches se agregan, prueban y editan desde la interfaz (solo administradores); las credenciales quedan en `switches.json` (permisos 600) y la API no las devuelve. Es de solo lectura: las operaciones destructivas de los equipos están bloqueadas.
- **Nueva Funcionalidad:** Switch Monitor, **distribución del panel frontal** configurable (una fila o dos filas alternadas; con SNMP y 16 o más puertos se elige la alternada, como en los TP-Link) y puertos ordenados por su número físico.
- **Nueva Funcionalidad:** Switch Monitor, **bytes reales por SNMP** (TP-Link): Mb/s, total por puerto y gráficos de tráfico.
- **Nueva Funcionalidad:** Switch Monitor, **bytes estimados en ZX y HC**: como solo informan paquetes, se calculan paquetes × tamaño medio (800 B por defecto, configurable por switch; 0 lo desactiva). Siempre aparecen marcados con «≈» y no son exactos. Si el firmware del HC trae columnas de bytes, se usan las reales.
- **Nueva Funcionalidad:** Switch Monitor, subpestaña **Historial**: totales acumulados por puerto que no se pierden con reinicios del switch ni de LabTower (se suma lo que avanza cada contador entre lecturas).
- **Nueva Funcionalidad:** Switch Monitor, subpestaña **Tabla MAC**: buscador por MAC, IP, nombre, switch o puerto, cruzado con los equipos que conoce Net Monitor. En el HC hay una opción para leer toda la tabla MAC (desactivada por defecto).
- **Nueva Funcionalidad:** Switch Monitor, **mapa de topología** con nodos arrastrables (la posición se recuerda en el navegador).
- **Nueva Funcionalidad:** Resumen: la tarjeta Net Monitor lista los switches (puertos arriba y temperatura) y los avisos incluyen switch sin conexión, temperatura alta o crítica, errores nuevos y loop. La línea de tiempo registra caídas, temperatura, errores, cambios de enlace y loops (en español e inglés).
- **Nueva Funcionalidad:** Respaldo (Teleporter, copia previa a actualizar y a desinstalar): incluye `switches.json` y `switches.db`.
- **Nueva Funcionalidad:** Tema: junto al icono ◐ ahora hay un botón que muestra el modo elegido (OSCURO / CLARO / AUTO, o DARK / LIGHT / AUTO en inglés), como los de «24H» y «ES». Se puede pulsar cualquiera de los dos para cambiar. Reemplaza la «A» pequeña del icono.
- **Nueva Funcionalidad:** Resumen, tarjeta «LabTower Server»: muestra el estado del último respaldo SFTP (OK, atrasado si pasan más de 36 h, o falló) con hace cuánto se hizo. Si falló o está atrasado, también aparece en los avisos. No se muestra si el respaldo no está configurado.

- **Mejora:** NAS Monitor, «Actividad de disco»: solo lista los discos con actividad real (≥ 5 % o ≥ 256 KB/s); los que están en reposo se resumen en una línea («Todos los discos en reposo (8)») en vez de ocho filas con 0 %.

- **Fix:** Switch Monitor, HC: el inicio de sesión tolera que el equipo responda HTTP 400 al POST; si el equipo cierra la conexión sin responder se reintenta una vez, y en la lectura de la tabla MAC se conserva lo leído en vez de fallar. Los errores HTTP de los switches indican qué petición falló.
- **Fix:** Switch Monitor, SNMP: se omiten las interfaces virtuales y la numeración de puertos sale del nombre (`…1/0/N`).
- **Fix:** Resumen: LabTower se identifica como servidor/VM y solo dice «Pi» cuando el equipo es una Raspberry Pi.
- **Fix:** Respaldo SFTP: `openssh-client`, `gnupg`, `gpg-agent`, `openssl` y `cron` pasan a ser dependencias obligatorias del paquete (antes `gnupg` era solo recomendado y faltaba `gpg-agent`, por lo que el cifrado fallaba en instalaciones mínimas con «No agent running»).
- **Fix:** Paquete: tras revisar los comandos que usan los módulos y los scripts, también se declaran `iproute2` (`ip`), `systemd` (`systemctl`, `journalctl`), `curl` (`labtower-health`), `ca-certificates` (descargas HTTPS), `passwd` (`useradd`, `usermod`, `userdel`), `hostname` y `awk`.
- **Fix:** `labtower-sftp-backup status` ya no se cae con un archivo de estado vacío o dañado: lo explica e indica cómo regenerarlo.
- **Fix:** El archivo de estado se sincroniza a disco antes de renombrarse, para que un corte brusco no lo deje vacío.

## 2.1.1 — 2026-10-27

Reúne todos los cambios desde 2.1 (builds 2.1a a 2.1n).

- **Nueva Funcionalidad:** Nuevo aspecto: tema oscuro por defecto (claro y «Auto» siguen disponibles), tarjetas más redondeadas con un leve brillo, títulos pequeños en mayúsculas, cifras grandes, tablas densas, menú lateral con acento y barra superior translúcida. Lo usan todos los módulos, el panel Admin y la página de inicio, desde una hoja común (`theme.css`/`theme.js`). Ya no se cargan tipografías de Google: se usa la del sistema (San Francisco en Apple).
- **Nueva Funcionalidad:** Tema: el botón ◐ del Resumen y de la página de inicio rota entre oscuro, claro y «Auto» (sigue el modo del sistema, con una «A» en el botón; cambia solo cuando cambia el del sistema).
- **Nueva Funcionalidad:** Resumen, modo kiosko: las tarjetas se acomodan en mosaico por columnas (la siguiente va a la columna más baja, respetando tu orden) en vez de filas de igual altura. Así una tarjeta corta ya no deja un espacio blanco debajo y caben más datos en el iPad. Se recalcula al refrescar y al girar la pantalla.
- **Nueva Funcionalidad:** Resumen, tarjeta de WAN Monitor: nuevo gráfico de latencia de las últimas 24 h (línea azul con espacios donde no hubo respuesta y franjas rojas donde el enlace estuvo caído), con el mínimo y máximo; se actualiza cada minuto.
- **Nueva Funcionalidad:** Resumen, tarjeta de DNS Monitor: gráfico del % bloqueado de las últimas horas, ajustado al rango real para que se vea la variación.
- **Nueva Funcionalidad:** WAN Monitor: nueva opción «Motor de la prueba» en Ajustes. Además del integrado (Cloudflare), se puede usar Ookla Speedtest CLI o LibreSpeed CLI si están instalados, para contrastar la velocidad. Ookla es solo para uso personal no comercial. El paquete sugiere `librespeed-cli`.
- **Mejora:** La tarjeta «Raspberry Pi» del Resumen ahora se llama «LabTower Server» (también su ventana de detalle).
- **Mejora:** DNS Monitor: el color pasa de rosa a verde esmeralda (página, icono y paleta de marca).

- **Fix:** NAS Monitor, actividad de disco: marcaba 0 % en todos los discos porque la columna de carga instantánea del NAS casi siempre vale 0. Ahora usa el mayor entre ella y el promedio de 1 minuto, y muestra además la lectura y escritura reales (R/W por segundo) calculadas con los contadores del disco.
- **Fix:** Admin, restaurar respaldos: fallaba con «file not found» porque la copia temporal quedaba en un /var/tmp privado del servicio. Ahora se guarda en `/var/backups/labtower`.
- **Fix:** WAN Monitor, prueba de velocidad: pide bloques de 25 MB y envía cabeceras de navegador; si el servidor la rechaza, el error dice por qué (por ejemplo «HTTP 403»). Si falla solo la subida, se conserva el resultado de la bajada.
- **Fix:** DNS Monitor: si no encuentra la API de Pi-hole, el mensaje dice qué probar (revisar el puerto, o usar https:// si Pi-hole solo escucha en el 443).
- **Fix:** Resumen, detalle del servidor: «Logged-in users» ahora también muestra a quien entró por SSH o por consola en equipos sin utmp ni logind (DietPi, Debian 13 mínimo).
- **Fix:** Teléfono: WAN Monitor muestra sus 5 tarjetas de arriba en 2 columnas (la IP pública a lo ancho), y las tablas resumen de NAS y DNS son más compactas y ya no se cortan por la derecha (en DNS se oculta la flecha de expandir; tocar la fila sigue expandiendo).

- **Mejora:** Los commits ya no llevan referencias a sesiones de Claude: `scripts/git-hooks/commit-msg` las quita (activar con `git config core.hooksPath scripts/git-hooks`; para permitirlas a propósito, `LABTOWER_ALLOW_CLAUDE_SESSION=1`) y una prueba revisa que ningún archivo las tenga.

## 2.1 — 2026-10-27

Dos módulos nuevos.

- **Nueva Funcionalidad:** DNS Monitor (`/dns/`, puerto 8087): uno o varios Pi-hole (v6 y v5, se detecta solo) o AdGuard Home. Muestra consultas, % bloqueado, clientes, dominios en listas, tiempo de respuesta, los más consultados y bloqueados, clientes más activos, DNS de salida, consultas por hora e historial. Permite pausar y reanudar el bloqueo (permiso «execute»). La contraseña o el token se guardan con permisos 0600 y no vuelven al navegador.
- **Nueva Funcionalidad:** WAN Monitor (`/wan/`, puerto 8088): latencia, jitter y pérdida (ping o TCP a varios destinos), tiempo de resolución DNS, puerta de enlace, cortes (distingue «sin internet» de «sin red local»), IP pública con aviso de cambio, disponibilidad a 24 h, 7 y 30 días, y prueba de velocidad programada o a pedido (bajada, subida y ping, contra un servidor compatible con Cloudflare). Mientras corre la prueba se pausan las mediciones.
- **Nueva Funcionalidad:** Permisos `dns` y `wan` por usuario en el panel Admin; ambos módulos en el menú, la portada, el Resumen (tarjetas y línea de tiempo), la salud del sistema, los respaldos y el teleporter.
- **Mejora:** El paquete depende de `iputils-ping`. Iconos nuevos para los dos módulos.

## 2.0.1 — 2026-10-27

Reúne los cambios de los builds 2.0a a 2.0c: solo cambia la imagen, no hay cambios de funcionamiento.

- **Mejora:** Icono nuevo: una pila isométrica de tres niveles. Está en el home, el Resumen, la pestaña del navegador, el icono de la app instalada (iPad, teléfono) y el README. `assets/icons/make-icons.py` genera todo desde `icon-source.png`.
- **Mejora:** Cada módulo tiene su icono (Resumen, UPS, Red, Proxmox, NAS, WOL y Admin): el mismo símbolo de siempre sobre una plataforma isométrica del color del módulo. Aparecen en las tarjetas de la página de inicio y en la pantalla de acceso de cada módulo.
- **Mejora:** Kit de marca en `assets/brand/`: los iconos de módulo (SVG y PNG) y la paleta (`palette.css`, `palette.json`), generados con `assets/brand/make-brand.py`.
- **Mejora:** Los respaldos con nombre `pi-console-*` se siguen pudiendo restaurar.

## 2.0 — 2026-10-27

**El proyecto se llama LabTower** (antes Pi Console). Ya no es solo para la Raspberry Pi y había muchos proyectos con el nombre anterior. Hay logo nuevo (una torre de tres niveles con los nodos arriba) en el menú, la página de inicio, los iconos de la app y las capturas.

- **Mejora:** El paquete ahora es `labtower` (reemplaza a `pi-console`). Cambian las rutas: `/opt/labtower`, `/var/lib/labtower`, `/etc/labtower`, `/var/log/labtower` y `/var/backups/labtower`.
- **Mejora:** El usuario del sistema es `labtower` y los servicios `pi-console-ups` y `pi-console-overview` pasan a `labtower-ups` y `labtower-overview`. Los demás servicios (`wol-console`, `admin-panel`, `net-monitor`, `proxmox-monitor`, `nas-monitor`) conservan el nombre.
- **Mejora:** Los comandos son `labtower-https`, `labtower-health`, `labtower-resources` y `labtower-sftp-backup` (`teleporter` no cambia).
- **Mejora:** Las variables de entorno `PICONSOLE_*` pasan a `LABTOWER_*` y la zona de nginx a `labtower_*`.

**Al actualizar:** se hace sola. Al instalar el paquete nuevo, dpkg retira `pi-console` y el instalador mueve los datos, usuarios, certificados HTTPS, configuración del respaldo SFTP y respaldos anteriores, y renombra el usuario y las variables de `/etc/default`. Las contraseñas y los datos no cambian; hay que iniciar sesión otra vez. Los respaldos hechos con la 1.x (`pi-console-*.tar.gz`) se pueden seguir restaurando desde Teleporter. Si usabas los comandos `pi-console-*` en scripts propios, hay que cambiarles el nombre.

## 1.4 — 2026-10-27

Reúne los cambios de los builds 1.3a a 1.3g.

**NAS Monitor** (`/nas/`, puerto 8086)
- **Nueva Funcionalidad:** Módulo nuevo para ver uno o varios NAS Synology, igual que se agregan clusters de Proxmox o servidores de UPS.
- **Nueva Funcionalidad:** Lee por **SNMP v3** (usuario, nivel, clave de autenticación y de cifrado, como en Net Monitor) o por v2c. Tiene botón *Probar conexión* antes de guardar.
- **Nueva Funcionalidad:** Página principal como la de UPS Monitor: tabla **Resumen de NAS** con todos los NAS; cada fila se abre y muestra el detalle. Por defecto se abre el primero.
- **Nueva Funcionalidad:** El detalle trae medidores (CPU, RAM, volumen, temperatura, discos, tiempo encendido), volúmenes, discos, red, UPS conectado y tres gráficos (CPU/RAM, temperatura y red) con rangos 1h / 1d / 1mo / Todo y los valores al pasar el cursor.
- **Nueva Funcionalidad:** Avisa disco con falla, volumen degradado o casi lleno, temperatura alta y actualización de DSM. Un Storage Pool lleno no avisa. Los avisos también salen en el Resumen.
- **Nueva Funcionalidad:** Nuevo permiso «NAS» en el Admin Panel, tarjeta en la página de inicio y en el Resumen (con la temperatura en su gráfico), y entrada en el menú de todos los módulos.
- **Nueva Funcionalidad:** Las claves SNMP se guardan con permisos 600, la API nunca las devuelve y no se pasan por la línea de comandos.
- **Nueva Funcionalidad:** Los respaldos (Teleporter) incluyen la lista de NAS. Pruebas nuevas en `tests/test_nas_monitor.py`.

- **Seguridad:** Proxmox Monitor: el estado de Ceph y la cantidad de núcleos del nodo se mostraban sin escapar. Un Proxmox comprometido podía meter HTML en la página. Ahora el estado de Ceph solo acepta `HEALTH_OK`, `HEALTH_WARN` o `HEALTH_ERR` (si no, muestra `UNKNOWN`), y los demás valores remotos se escapan o se convierten a número.
- **Seguridad:** Protección CSRF: en navegadores que no envían `Sec-Fetch-Site` (Safari antiguo) ahora también se comparan el esquema y el puerto del origen, no solo el nombre del host. nginx pasa `X-Forwarded-Proto` y `X-Forwarded-Port` a los servicios.
- **Seguridad:** Pruebas nuevas (`tests/test_security_hardening.py`) para ambos casos.

- **Mejora:** Los workflows de GitHub Actions se actualizaron a mano (dependabot). Se quitaron las notas de release antiguas. 69 pruebas automáticas (eran 43).

**Al actualizar:** no hay cambios de configuración. El permiso «NAS» se agrega solo a los usuarios existentes: administrador para quien administra WOL y solo lectura para el resto. Se puede cambiar en el Admin Panel.

## 1.3 — 2026-10-23

Reúne los cambios de los builds 1.2.2a a 1.2.2g.

- **Mejora:** Nueva licencia: **PolyForm Noncommercial 1.0.0** (antes MIT). Uso gratis para uso personal, hobby, estudio, educación y organizaciones sin fines de lucro. El uso comercial y los derivados comerciales requieren permiso escrito del autor. Las versiones anteriores siguen con su licencia MIT.
- **Mejora:** El paquete incluye `/usr/share/doc/pi-console/copyright` y `LICENSE`.

- **Nueva Funcionalidad:** Overview: tarjetas ordenables. Botón *Ordenar*: flechas ‹ › y manija ⠿ para arrastrar (las flechas sirven en iPad y celular). *Restablecer orden* vuelve al de siempre (UPS, Proxmox, Red, Pi). El orden se guarda en cada navegador y también se usa en modo kiosko.
- **Nueva Funcionalidad:** Formato de hora 24 h / 12 h. Botón "24H/12H" junto al idioma. Por defecto 24 h. Se guarda en el navegador y vale para todos los módulos.
- **Nueva Funcionalidad:** UPS Monitor: tiempo en línea y disponibilidad. Tiempo en línea desde el último corte, disponibilidad de 24 h, 7 d y 30 d, cortes de los últimos 30 días y último corte (fecha, duración y carga mínima). Al actualizar se reconstruyen los cortes pasados desde el historial (solo si el UPS informa voltaje de entrada). La disponibilidad aparece con al menos 1 hora de datos. El Overview muestra una línea con lo mismo.
- **Nueva Funcionalidad:** Overview: detalle de la Raspberry Pi. El botón *Abrir* de la tarjeta Raspberry Pi muestra equipo, sistema, kernel, uptime, CPU total y por núcleo, frecuencia, carga, memoria y swap, discos, red con IP y tráfico, temperatura y estado de energía. Los administradores también ven usuarios conectados, procesos con más CPU y memoria, y servicios con falla. Se actualiza cada 5 s. También se ve en modo kiosko.

- **Seguridad:** Auditoría de lo nuevo: sin hallazgos críticos ni altos.
- **Seguridad:** El detalle de la Pi comparte el resultado 2 s entre sesiones, para que muchas peticiones no carguen la Pi. Las direcciones MAC solo las ven los administradores.
- **Seguridad:** Cortes del UPS: máximo 2000 por UPS, para que un UPS defectuoso no haga crecer la base.

- **Fix:** Detalle de la Pi: los usuarios conectados no aparecían en Raspberry Pi OS nuevo (Debian 13). Ahora se leen también de systemd-logind.

- **Mejora:** Pruebas automáticas en el repositorio (`tests/`, 31 pruebas, solo biblioteca estándar) y en GitHub Actions.
- **Mejora:** Los módulos ya no crean archivos ni carpetas al importarse; se preparan al arrancar el servicio.

## 1.2.2 — 2026-10-20

Reúne todos los cambios desde 1.2.1 (builds 1.2.1a a 1.2.1t).

- **Seguridad:** CSRF: las peticiones que modifican datos se rechazan si no vienen de la propia página.
- **Seguridad:** CSP estricta: sin scripts ni manejadores en línea (`script-src 'self'`). Navegadores: Chrome 75+, Firefox 105+, Safari 15.4+.
- **Seguridad:** XSS corregido en los 5 paneles. Incluye el que venía del servidor NUT (un equipo de la red podía ejecutar código en el navegador del administrador).
- **Seguridad:** WOL: el límite por IP ya no se evade con `X-Forwarded-For`. "Despertar todos" también tiene límite.
- **Seguridad:** Net Monitor: el escaneo de una IP solo acepta equipos de la red escaneada.
- **Seguridad:** Redirección abierta en el cambio de contraseña corregida.
- **Seguridad:** La contraseña inicial del admin ya no se escribe en el journal. Los hashes antiguos se migran a scrypt.
- **Seguridad:** Respaldo SFTP: el archivo de estado ahora está en `/var/log/pi-console/backup.status` (carpeta de root).
- **Seguridad:** Teleporter: se rechazan respaldos que descomprimen a más de 2 GiB. Dos subidas simultáneas ya no se pisan.
- **Seguridad:** Revisión final del código con bandit y shellcheck. Sin hallazgos críticos ni altos.

- **Nueva Funcionalidad:** Login: "Recordarme" (1 día, 1 semana, 1 mes o siempre). Sin marcar, 24 h.
- **Nueva Funcionalidad:** Admin: tarjeta "Sesiones activas" para ver y cerrar sesiones.
- **Nueva Funcionalidad:** Overview: selector de intervalo de actualización (10 s a 5 min, o manual).
- **Nueva Funcionalidad:** Net Monitor: botón de basurero para eliminar equipos. Categorías nuevas: Game Console, Servidor, Teléfono IP, UPS y Altavoz inteligente.
- **Nueva Funcionalidad:** Tarjeta de Net Monitor al pasar el mouse (o tocar en iPad) por una IP en UPS, Proxmox, WOL y Overview.
- **Nueva Funcionalidad:** Nuevo icono de la app y soporte para pantalla de inicio en iPad/iPhone (pantalla completa, icono incrustado).
- **Nueva Funcionalidad:** HTTPS autofirmado compatible con iOS. `pi-console-https enable` regenera el certificado antiguo una vez; hay que instalarlo de nuevo en cada dispositivo.

- **Fix:** Admin: el login con Enter abría dos sesiones.
- **Fix:** UPS Monitor: anillos y etiquetas de los gráficos ya no se cortan.
- **Fix:** Las duraciones de más de 24 h se ven en días (`1d 16h`).

**Al actualizar:** `pi-console-site.conf` cambió. Si lo editaste, dpkg preguntará; conserva el nuevo. Si ya tenías la app en la pantalla de inicio, quítala y agrégala otra vez.

## 1.2.1 — 2026-10-15

Versión estable de la serie 1.2 (reúne 1.2.0a–x). El funcionamiento es el de 1.2.0x, salvo lo indicado.

- **Mejora:** Sin claves, tokens ni credenciales en el código, el historial de git ni el `.deb`.
- **Mejora:** Sin datos personales ni de red: solo quedan el nombre del autor y direcciones de documentación (`192.0.2.0/24`).
- **Mejora:** 38 pruebas de integración; instalación, actualización, desinstalación y purga del `.deb` probadas.

- **Mejora:** Paquete: al purgar, los datos conservados pasan a `root:root` (700) y se devuelven al usuario del servicio al reinstalar. Antes quedaban a nombre de un uid huérfano.
- **Mejora:** Páginas: la metaetiqueta `author` ya no incluye el correo.
- **Mejora:** Documentación: capturas rehechas con datos ficticios y la versión actual; ruta local quitada de `docs/APT.md`.

## 1.2.0x — 2026-10-15

- **Mejora:** UPS Monitor: los gráficos de voltaje, consumo y temperatura de cada UPS ocupan ahora todo el ancho del detalle (más amplios y sin el espacio que dejaba el de temperatura al quedar solo en una fila). En pantallas angostas ya iban a todo el ancho.

## 1.2.0w — 2026-10-15

- **Mejora:** Resumen: las tarjetas se reparten de forma equilibrada. Si no caben todas en una fila (4 tarjetas con sitio para 3 columnas, típico en pantallas de ~1000–1300 px), pasan a 2×2 en vez de dejar la última sola en una segunda fila con un espacio a su derecha. En kiosko el ancho mínimo por tarjeta baja de 380 a 320 px: 4 tarjetas caben en una fila desde ~1400 px.

## 1.2.0v — 2026-10-15

- **Fix:** Resumen, kiosko y pantallas anchas: la línea de tiempo estaba dentro de la grilla de tarjetas y, al ocupar todas las columnas, reservaba una columna vacía a la derecha: con 4 tarjetas y un ancho de ~1100–1200 px quedaba cerca de un 20 % de la pantalla sin usar. Ahora la línea de tiempo va debajo de la grilla y las tarjetas reparten todo el ancho.

## 1.2.0u — 2026-10-15

- **Seguridad:** Instalador y Teleporter como root: ya no siguen enlaces simbólicos dentro de carpetas que controlan los servicios (antes un servicio comprometido podía hacer que un respaldo incluyera archivos de root o que una restauración los sobrescribiera). Las lecturas las hace el usuario del servicio y las escrituras usan `openat` con `O_NOFOLLOW`; la instantánea SQLite la toma el usuario del servicio; el registro de restauración está en `/var/log/pi-console/` (de root); `/opt/pi-console` y `/opt/pi-console-auth` son de root. Teleporter 2.2.0.
- **Seguridad:** Servicios: el código es de solo lectura para ellos y los datos pasan de `/opt/pi-console/<módulo>/` a `/var/lib/pi-console/<módulo>/` (el instalador los mueve solo). Unidades systemd endurecidas (`ProtectSystem`, `ProtectHome`, `PrivateTmp`, `NoNewPrivileges` donde no hay `ping` ni `sudo`, familias de sockets, `UMask=0077`…).
- **Seguridad:** CSV de UPS Monitor: el nombre del archivo exportado ya no puede inyectar cabeceras (CRLF).
- **Seguridad:** HTTPS: nuevo comando `pi-console-https` (`enable [--redirect] [--cert --key]`, `disable`, `status`) con certificado autofirmado o propio, HSTS y cookie `Secure` al redirigir.
- **Seguridad:** Intentos de login: contadores compartidos por todos los módulos (archivo con `flock`), límite por IP y por cuenta; cambiar la contraseña exige la actual y esos intentos también se limitan.
- **Seguridad:** Respaldos: no incluyen `sessions.json`; el respaldo SFTP se **cifra con gpg** (AES-256) antes de salir (`pi-console-sftp-backup decrypt` para abrirlo; la contraseña está en `/etc/pi-console/backup_passphrase`, guarda una copia fuera de la Pi).
- **Seguridad:** Cuentas: sin `admin`/`admin`: contraseña aleatoria en la instalación nueva (la muestra el instalador); mínimo 8 caracteres también al crear usuarios.
- **Seguridad:** Permisos: un usuario de solo lectura ya no puede iniciar un escaneo de Net Monitor; un admin parcial (p. ej. solo WOL) no puede degradar, borrar ni cambiar la contraseña del administrador principal.
- **Seguridad:** Hosts y Pi-hole: hosts y nombres de NUT, Proxmox y Pi-hole se validan; el certificado de Pi-hole se fija en la primera conexión (TOFU).
- **Seguridad:** nginx: `server_tokens off`, límites de peticiones y conexiones por IP (más estricto en el login), `Content-Length` negativo rechazado, cabeceras adicionales; `/api/health` público solo informa el estado y `/api/version` pide sesión. Se quita el endpoint `/wol/api/token` (sin uso).
- **Seguridad:** Sesiones: se guardan solo como hash SHA-256 y el login ya no devuelve el token en el JSON. **Hay que iniciar sesión otra vez tras actualizar.**
- **Seguridad:** Admin Panel: un usuario válido que no es admin recibe la misma respuesta que una contraseña incorrecta (sin oráculo de credenciales).
- **Seguridad:** Límite conocido: la CSP todavía permite `'unsafe-inline'` (resuelto en 1.2.1f).

## 1.2.0t — 2026-10-15

- **Fix:** Resumen, kiosko: el gráfico de temperatura de la UPS se muestra ahora en cualquier tamaño de pantalla, de forma compacta (en 1.2.0s seguía oculto entre 701 y 900 px de alto, que es el caso de varias tablets de 7").

## 1.2.0s — 2026-10-15

- **Fix:** Resumen, kiosko de 7": el gráfico de temperatura de la UPS no aparecía en pantallas de 700 px de alto o menos; ahora se muestra compacto, como los de la Pi y Proxmox. Entre 701 y 900 px sigue oculto para que quepa la pantalla.
- **Mejora:** Resumen, kiosko: leyenda de la torta de Net Monitor en dos columnas con etiquetas cortas y título más compacto en el gráfico de temperatura de la Pi.
- **Mejora:** Sin referencias a redes privadas: el servidor SFTP por defecto de `backup.conf` es ahora `storage.example.lan` (hay que indicar el real en `SFTP_HOST`); la red de respaldo de Net Monitor cuando no se detecta la IP es `192.0.2.0/24`.
- **Mejora:** Documentación y capturas (claro y oscuro) actualizadas.

## 1.2.0r — 2026-10-14

- **Fix:** Resumen, Net Monitor: la leyenda de la torta mostraba solo los 6 tipos más numerosos, así que TV, teléfono, tablet, cámara, etc. podían quedar fuera aunque estuvieran en la torta. Ahora aparecen **todos** los tipos (hasta 12, con colores distintos); con más de 5 se ordenan en dos columnas. En el kiosko de pantalla chica la torta se achica y se usan nombres cortos (PC, Teléf., Cám., Impres.…) para que quepan todos sin cambiar el alto de las tarjetas.
- **Mejora:** Resumen, temperatura de la Pi: el gráfico ya no reserva siempre 24 h de ancho: usa todo el ancho para los datos acumulados (2 min, 1 h, 24 h…) y el título indica el período que cubre («Temp 35 min»).

## 1.2.0q — 2026-10-14

- **Nueva Funcionalidad:** UPS Monitor: gráfico de temperatura de la UPS. En el detalle de cada UPS aparece, junto a los de voltaje y consumo, el gráfico de temperatura con los mismos rangos (1 h, 1 día, 1 mes, todo), cursor con valor y modo claro/oscuro. Solo se muestra si la UPS informa `ups.temperature` o `battery.temperature`; si no, no aparece. Usa el historial que ya se guardaba en `history.db`, así que muestra de inmediato lo registrado antes.
- **Fix:** En los rangos largos se promedian solo las lecturas con temperatura (antes un 0 por «sin dato» bajaba el promedio) y la línea se corta donde no hubo lectura.

## 1.2.0p — 2026-10-14

- **Mejora:** Los históricos de los gráficos del Resumen pasan de archivos JSON a una base **`/var/lib/pi-console/metrics.db`** (tablas `pi_samples` y `pve_samples`), compartida por el Resumen (temperatura y bajo voltaje de la Pi) y Proxmox Monitor (CPU y memoria de los nodos). Es el mismo motor que el historial de la UPS (`history.db`).
- **Mejora:** Cada muestra se guarda al instante (modo WAL): un corte de luz ya no pierde los últimos minutos, y no se reescribe un archivo completo cada vez.
- **Mejora:** Retención configurable: 7 días por defecto; `PICONSOLE_PI_KEEP_DAYS` (Pi) y `PVE_KEEP_DAYS` (Proxmox) la cambian, de 1 a 365. Los gráficos siguen mostrando 24 h (Pi) y 12 h (Proxmox).
- **Mejora:** Migración automática: si existen `pi-history.json` o `proxmox-monitor/history.json` (versión 1.2.0o), se importan una vez a la base y se renombran a `.migrated`.
- **Mejora:** Teleporter respalda `metrics.db` con la API de respaldo de SQLite (consistente aunque los servicios estén escribiendo) y la verifica. Restaura también respaldos de la 1.2.0o, que traían los JSON; los servicios los importan.
- **Mejora:** En un equipo que no es Raspberry Pi no se crea hilo ni tabla de la Pi.

## 1.2.0o — 2026-10-14

- **Mejora:** Proxmox: CPU y memoria (12 h). Antes vivían solo en memoria y se perdían al reiniciar Proxmox Monitor o actualizar el paquete. Ahora se guardan en `proxmox-monitor/history.json` cada 5 min y al detener el servicio, y se recargan al arrancar (se descartan las muestras de más de 12 h y los clusters que ya no existen). También se conservan al desinstalar y reinstalar (`preinst`/`prerm`/`postinst`).
- **Mejora:** Pi: temperatura y bajo voltaje (24 h) en `/var/lib/pi-console/pi-history.json` (ya persistente desde 1.2.0m).
- **Mejora:** UPS: temperatura (24 h) ya estaba en `history.db`.
- **Mejora:** Teleporter respalda y restaura `proxmox-monitor/history.json` y `pi-history.json` (el `history.db` de la UPS ya estaba). Los respaldos antiguos siguen siendo válidos (sin esos archivos se conservan los actuales).
- **Mejora:** Un corte de luz brusco puede perder los últimos minutos del historial (se escribe cada 5 a 10 min para cuidar la SD).

## 1.2.0n — 2026-10-14

- **Fix:** Kiosko de 7": los gráficos de la Pi (temperatura y bajo voltaje) y de Proxmox (CPU y memoria) ya no se ocultan en pantallas bajas; se muestran compactos (28 px) y no cambian el alto de la página. El de temperatura de la UPS sigue oculto en kioskos de menos de 900 px de alto.

## 1.2.0m — 2026-10-14

- **Nueva Funcionalidad:** Raspberry Pi: temperatura y bajo voltaje (24 h). El servicio Resumen anota cada minuto la temperatura y los bits de `get_throttled` y guarda las últimas 24 h en `/var/lib/pi-console/pi-history.json` (se escribe cada 10 muestras y al cerrar el servicio, y se retoma al reiniciar). El gráfico marca en **rojo** la subtensión (también la que ocurrió entre dos muestras y ya pasó) y en **ámbar** la limitación por energía o temperatura; muestra mín., máx. y cuántos episodios de subtensión hubo. **Solo existe en una Raspberry Pi**: en otros equipos no se crea hilo, archivo ni gráfico (`/api/pihistory` responde `pi:false`).
- **Nueva Funcionalidad:** Proxmox: CPU y memoria (12 h) por cluster, con el historial que ya guardaba Proxmox Monitor (promedio de los nodos en tramos de 5 min). El historial se pide una vez por minuto; el resto de las actualizaciones siguen siendo livianas.
- **Nueva Funcionalidad:** UPS: temperatura (24 h) bajo el gráfico de carga, solo si la UPS informa temperatura (NUT `ups.temperature` o `battery.temperature`).
- **Nueva Funcionalidad:** En modo kiosko de pantalla baja (7") los gráficos nuevos se ocultan como los demás; el de temperatura de la UPS también en kioskos de menos de 900 px de alto, para que todo siga cabiendo.

## 1.2.0l — 2026-10-14

- **Nueva Funcionalidad:** `pi-console-sftp-backup` (`/usr/local/bin`) + cron diario a las 03:17 (`/etc/cron.d/pi-console-sftp-backup`): crea el respaldo con Teleporter, lo **verifica antes de subirlo** (`teleporter check`), lo envía por SFTP (por defecto a `storage.example.lan`) con nombre temporal `.part` que renombra al terminar, y compara el tamaño remoto con el local.
- **Nueva Funcionalidad:** Retención: 30 copias en el storage (`KEEP_REMOTE`) y 7 en la Pi (`KEEP_LOCAL`). Solo se borran archivos llamados `pi-console-auto-<equipo>-<fecha>_<hora>.tar.gz`; los demás archivos de la carpeta no se tocan.
- **Nueva Funcionalidad:** Seguro: solo llave SSH (sin contraseñas), la huella del servidor se fija en la primera conexión y un cambio hace fallar el respaldo, el archivo de configuración (`/etc/pi-console/backup.conf`) se *lee* y nunca se ejecuta (solo claves conocidas, valores validados), un solo respaldo a la vez.
- **Nueva Funcionalidad:** Comandos: `setup` (crea la llave y muestra la pública), `test` (conexión, carpeta, escritura), `run`, `status`. Resultado en `/var/lib/pi-console/backup.status` y en `journalctl -t pi-console-sftp-backup`.
- **Nueva Funcionalidad:** No confundir con el atajo antiguo `pi-console-backup`, que sigue igual y equivale a `teleporter backup`; el nuevo se llama `pi-console-sftp-backup`.
- **Nueva Funcionalidad:** Viene **desactivado** hasta completar `SFTP_USER`. El paquete recomienda `openssh-client` y `cron`; la llave y la huella se borran con `apt purge`.

## 1.2.0k — 2026-10-14

**Resumen**
- **Fix:** «Equipos nuevos» cortado en el kiosko de tablets chicas: en tarjetas angostas la fila (etiqueta NEW + IP + nombre) se salía del borde de la tarjeta. Ahora el nombre puede achicarse y en el kiosko compacto va en una segunda línea, con puntos suspensivos si es muy largo, y la etiqueta es más pequeña. En otras pantallas el nombre largo se parte en vez de cortarse.

## 1.2.0j — 2026-10-14

**Resumen**
- **Mejora:** Desplazamiento automático apagado por defecto: ahora se activa con el botón «Auto-desplazar», que aparece junto a «Salir de kiosko» al mover el mouse o tocar la pantalla (solo si el contenido no cabe). Se apaga con el mismo botón, siempre vuelve apagado al entrar al kiosko y con `?autoscroll=1` arranca encendido. Reemplaza al parámetro `?autoscroll=0` de la 1.2.0h.
- **Fix:** Toque accidental: el primer toque solo muestra la barra de botones; ya no pulsa un botón que todavía estaba invisible (podía sacar del kiosko sin querer). La barra queda visible 4 s.

## 1.2.0i — 2026-10-14

**Resumen**
- **Mejora:** Kiosko compacto para tablets de 7" y portátiles (≤ 1399 px de ancho): tarjetas con menos margen y relleno, KPIs más chicos, hasta 4 tarjetas en una fila y las filas de las unidades que se envuelven en vez de salirse de la tarjeta. En pantallas bajas (≤ 700 px de alto, como 1024×600) se ocultan los gráficos de 24 h y se resumen la línea de tiempo (4 eventos), la leyenda de tipos y los equipos nuevos, de modo que todo cabe sin scroll. Más grande que 1399 px no cambia nada.

## 1.2.0h — 2026-10-14

**Resumen**
- **Nueva Funcionalidad:** Modo kiosko para pantallas chicas (tablet de 7"): el tamaño de letra y de columnas se adapta al ancho de la pantalla (antes era fijo, pensado para 1920 px). `?zoom=0.5–2` ajusta el tamaño a gusto.
- **Nueva Funcionalidad:** Desplazamiento automático en kiosko cuando el contenido no cabe: sube y baja despacio con pausa arriba y abajo, se detiene 30 s al tocar la pantalla y se desactiva con `?autoscroll=0`.
- **Mejora:** El botón «Salir de kiosko» aparece también al tocar la pantalla (tablets sin mouse).

## 1.2.0g — 2026-10-14

**Resumen**
- **Fix:** Compatible con iPad antiguos (p. ej. iPad Air 1, iOS 12): el Safari de esa versión no soporta `gap` en flexbox (separaba mal cabecera, píldoras, filas y eventos) ni `:has()` (el modo kiosko no agrandaba la letra). La página detecta el soporte y usa márgenes de respaldo solo cuando hace falta, y el modo kiosko marca `<html>` con una clase en vez de `:has()`. En navegadores modernos el aspecto es el mismo (comparado píxel a píxel).

## 1.2.0f — 2026-10-14

**Resumen**
- **Fix:** Modo kiosko: el botón «Salir de kiosko» (arriba a la derecha) se sobreponía al texto «Actualizado hace…»; ahora la barra superior le deja sitio.

## 1.2.0d — 2026-10-14

**Resumen**
- **Fix:** Mensajes de servidor UPS sin conexión legibles: el aviso y la línea de tiempo mostraban el identificador interno del servidor (un UUID); ahora dicen el nombre y la dirección, p. ej. «Servidor UPS Sala técnica (ups.example.lan:3493) sin conexión: Timeout connecting to upsd». La tarjeta de UPS también usa el nombre del servidor.

## 1.2.0c — 2026-10-14

- **Nueva Funcionalidad:** Página de resumen con lo principal de UPS Monitor, Proxmox Monitor y Net Monitor en una sola pantalla: estado global con lista de lo que requiere atención, tarjetas por UPS (estado, batería, carga, autonomía, vatios, gráfico de 24 h), por cluster Proxmox (nodos, VMs/CTs, CPU/memoria, Ceph) y de la red (en línea/conocidos/apagados, último escaneo, tipos de equipo, equipos nuevos de 48 h). Cada persona ve solo los módulos a los que tiene acceso. Claro/oscuro, español/inglés y móvil.
- **Nueva Funcionalidad:** Widget de la Raspberry Pi: temperatura, CPU, memoria, disco, tiempo encendida y problemas de la fuente de poder.
- **Nueva Funcionalidad:** Línea de tiempo de eventos: UPS pasa a batería / batería baja / vuelve la red, servidor UPS sin conexión, nodo Proxmox caído o recuperado, cluster sin conexión, cambios de salud de Ceph, equipos nuevos / que volvieron / que dejaron de responder (el primer escaneo se resume en una línea; más de 5 cambios iguales se agrupan). Los registra cada módulo en `/var/lib/pi-console/events.json` (máx. 300 eventos o 30 días), así que se guardan aunque nadie tenga la página abierta. Reiniciar un servicio no genera eventos falsos.
- **Nueva Funcionalidad:** Modo kiosko (`?kiosk=1` o botón): pantalla completa, letra grande, sin botones ni cursor y con la pantalla siempre encendida.
- **Nueva Funcionalidad:** Servicio nuevo `pi-console-overview` (puerto 8085, solo loopback), ruta `/overview/` en nginx, acceso «Overview» en el menú de todos los módulos y tarjeta «Resumen» en la página de inicio. Se incluye en la salud del sistema, en `pi-console-resources`, en Teleporter (reinicio tras restaurar) y en la desinstalación.

## 1.2.0b — 2026-10-13

Compilación de documentación y pulido sobre la 1.2.0 (no cambia el comportamiento de los módulos).

- **Mejora:** README reordenado (descripción, capturas, módulos, requisitos, instalación, actualizar, uso por módulo, operación, seguridad, estructura, licencia) y actualizado: primer ingreso con cambio de contraseña obligatorio, sección *Actualizar*, tabla de variables de entorno (`/etc/default/pi-console`), operación (`journalctl`, servicios, `remove`/`purge`), límite de intentos de login, requisitos (Raspberry Pi OS, DietPi o Debian 12+), estructura del repositorio y diagrama de arquitectura al día.
- **Mejora:** Nuevo `README.en.md` (resumen en inglés) y archivo `LICENSE` (MIT).
- **Mejora:** Capturas regeneradas para los 5 módulos en claro/oscuro y 4 resoluciones, más «Primer ingreso» y «Net Monitor vacío»; se quitaron las imágenes sueltas de la raíz.
- **Mejora:** `docs/APT.md` indica que el repositorio APT está preparado pero sin publicar.

- **Seguridad:** WOL Console: la clave CSRF (`WOL_SECRET`) ahora es aleatoria y se guarda con permisos 600 en `wol-console/.csrf-secret`; ya no hay un valor por defecto conocido.
- **Mejora:** Página de inicio: tarjetas en el orden del menú (UPS, Net, Proxmox, WOL) y nueva tarjeta de Admin Panel.
- **Mejora:** Se eliminó `auth/static/login.html` (código muerto, sin referencias).

## 1.2.0 — 2026-10-13

Release final de la serie 1.2: reúne la base 1.2.0 (12-oct) y las compilaciones de prueba de instalación nueva 1.2.0a a 1.2.0e, que se reemplazan por esta versión. Resumen por compilación, de la más nueva a la más antigua:


**Net Monitor**
- **Mejora:** El «Hacer escaneo inicial» se comporta igual que el botón «Escanear red»: ambos llaman a la misma función, pero el botón inicial tardaba ~1,5 s en reaccionar (seguía clicable y mostrando «Sin hosts descubiertos» hasta la primera consulta de estado). Ahora, venga de donde venga el clic, al instante se muestran la barra de progreso, el botón superior ocupado y la lista vacía en «Escaneando…».


- **Seguridad:** Permisos entre módulos («solo das lo que tienes»). En el Admin Panel, un administrador solo puede dar o quitar permisos en los módulos donde él mismo tiene ese nivel (un admin de WOL ya no puede dar ni quitar permisos en Net o Proxmox) y no puede borrar ni cambiar la contraseña de un usuario con más permisos que él. Los valores por defecto al crear un usuario se limitan a lo que el admin puede dar.
- **Seguridad:** Respaldos (Teleporter) solo para admins de todos los módulos: contienen hashes de contraseñas, tokens de Proxmox y la configuración completa. A los demás admins la tarjeta se les oculta y la API responde 403.
- **Seguridad:** Proxmox: aviso permanente de certificado sin verificar en cada cluster sin huella fijada (con el botón «Fijar certificado» para admins), y una advertencia en el log al arrancar el servicio.
- **Seguridad:** Cookie de sesión `Secure` opcional: con `PICONSOLE_SECURE_COOKIE=1` en `/etc/default/pi-console` (leído por las 5 unidades systemd) la cookie lleva `Secure`. Apagado por defecto: Pi Console se usa por HTTP en la LAN.
- **Mejora:** README: nueva sección **Seguridad** (uso en LAN de confianza por HTTP, HTTPS opcional delante, permisos por módulo, certificados de Proxmox).


- **Seguridad:** Cambio de contraseña obligatorio en el primer ingreso. La cuenta inicial `admin`/`admin` (y cualquier cuenta marcada «debe cambiar contraseña» desde el Admin Panel) pasa por una pantalla de cambio de contraseña antes de entrar a cualquier módulo; al guardarla vuelve al módulo desde el que ingresó y ya puede navegar a los demás. Se exige la contraseña actual, una nueva de al menos 6 caracteres y distinta de la actual.
- **Seguridad:** Se aplica en el servidor, no solo en la página: mientras la contraseña esté pendiente, la sesión no sirve en ningún módulo (todas las llamadas dan 401) salvo para cambiarla (`/admin/change-password`). Funciona con cualquier usuario, también sin permisos de administrador. Al cambiarla se cierran las demás sesiones de esa cuenta.
- **Mejora:** Net Monitor no escanea nada por defecto en una instalación nueva: arranca en modo manual (intervalo 0) y, cuando no hay equipos, la página muestra la red detectada y el botón **«Hacer escaneo inicial»**. Se puede activar el escaneo automático en Ajustes. Las instalaciones existentes conservan su intervalo.
- **Mejora:** En modo manual (intervalo 0) Net Monitor tampoco escanea al arrancar el servicio; antes lo hacía siempre una vez.
- **Mejora:** El escaneo va poblando la lista: cada equipo encontrado se guarda enseguida (como máximo cada 2 s) y la página se refresca cada 3 s durante el escaneo, sin esperar a que termine toda la red. Mientras escanea con la lista vacía muestra «Escaneando…».

**UPS Monitor**
- **Fix:** Primera UPS recién agregada: la tabla muestra «Conectando con el servidor NUT…» (en vez de «No UPS found») y la página refresca cada 1,5 s hasta que llegan los datos, sin recargar a mano. Las dos primeras lecturas de cada UPS se guardan de inmediato, así los gráficos tienen puntos a los pocos segundos en vez de esperar hasta 60 s.
- **Mejora:** El subtítulo «NUT · APC · Eaton» pasa a «NUT UPS».


- **Mejora:** UPS Monitor ya no crea un servidor «Local» por defecto: una instalación nueva empieza sin servidores (no hace falta tener una UPS); se agrega uno desde la página. Las instalaciones existentes conservan los suyos.
- **Mejora:** `snmp` pasa a ser dependencia del paquete (antes solo sugerida), para que la fuente SNMP de Net Monitor funcione sin pasos extra.
- **Mejora:** Net Monitor: la red a escanear por defecto es la /24 de la IP de la máquina (antes fijaba una red fija); se puede cambiar con `SCAN_NETWORK`. Los servidores Pi-hole ya no vienen precargados.
- **Mejora:** Los ejemplos (placeholders) de IP en WOL, UPS, Net Monitor y Proxmox usan direcciones de documentación (`192.0.2.x`) en lugar de IP de una red real.
- **Mejora:** Orden de navegación por defecto en todas las páginas: UPS Monitor, Net Monitor, Proxmox, WOL Console, Admin Panel (quien ya reordenó el menú conserva su orden).


- **Fix:** Instalación nueva: la página de inicio daba `500 Internal Server Error`. nginx servía `/` desde `/opt/pi-console-home/`, pero el paquete instala la portada en `/opt/pi-console/home/`; la carpeta antigua solo existía en equipos con instalación manual previa. Ahora nginx usa `/opt/pi-console/home` (también en actualizaciones: la portada se actualiza con el paquete).
- **Fix:** Documentación: la instalación indica `apt-get install ./pi-console_X.deb` (resuelve dependencias) en lugar de `dpkg -i`.


Primer release de la serie 1.2. Reúne todos los cambios de 1.1.8b a 1.1.9j (listados abajo) y agrega el código comentado.

- **Mejora:** Todo el código fuente lleva comentarios en **español** y, a continuación, en **inglés** (marcados con `EN:`): los 5 servicios Python, el módulo de autenticación, `teleporter.sh`, los scripts de salud y recursos, los scripts del paquete (`postinst`, `preinst`, `prerm`, `postrm`), la configuración de nginx y las 7 páginas HTML. Cada archivo empieza con un mapa de su estructura y el flujo de datos; cada función explica qué hace y, cuando importa, por qué.
- **Mejora:** Solo se agregaron comentarios; la lógica no cambió. Se verificó que el código sin comentarios quedara idéntico (Python por AST; shell, nginx y HTML por comparación de líneas, más `bash -n` y `node --check`).
- **Mejora:** Los mensajes de log y de error de los servicios que quedaban en español ahora están en inglés («Admin permission required», «Duplicate MAC», «Scan finished…», etc.).

**Interfaz**
- **Fix:** En pantallas de hasta 960 px la barra lateral estaba oculta y no había forma de cambiar de módulo. Ahora hay un botón de menú (☰) en la barra superior que abre la navegación como panel lateral, con fondo atenuado; se cierra al tocar el fondo, un enlace o con Esc. Aplica a WOL Console, UPS Monitor, Net Monitor, Proxmox y Admin Panel.
- **Mejora:** La barra superior pasa a varias filas en móvil para que todos sus controles (idioma, tema, usuario, escaneo) sean alcanzables.
- **Mejora:** Todas las páginas (WOL, UPS, Net Monitor, Proxmox y Admin, incluida la pantalla de login) muestran *Pi Console vX.Y.Z* en el pie. La versión sale del archivo `/opt/pi-console/VERSION` que instala el paquete, vía `GET /api/version` de cada servicio (también aparece en `/api/health`).
- **Fix:** Diseño: en pantallas de laptop (≈1366 px o menos) Net Monitor y WOL Console se salían de la pantalla por la derecha porque la barra superior no cabía; ahora la barra se acomoda en varias filas y no hay desbordamiento horizontal entre 320 y 1366 px. En móvil, el Admin Panel ya no se ensancha más que la pantalla (las tablas se desplazan dentro de su tarjeta).
- **Fix:** Net Monitor: textos que quedaban en español con la interfaz en inglés («Todos», «seg», «cada 1h», «hace 8m», tooltips, detalle del host, progreso del escaneo) ahora siguen el idioma elegido.
- **Mejora:** Móvil: en el Admin Panel las tablas se desplazan dentro de su tarjeta sin mover el título ni el botón *New user*, y la barra superior alinea sus márgenes con el contenido. En UPS Monitor la tabla de resumen cabe en pantallas de 360 px aunque el modelo/serie sea largo, y el panel de detalle del UPS queda siempre visible aunque la tabla se desplace.
- **Mejora:** Móvil: en el Admin Panel la lista de usuarios y la de backups pasan a tarjetas (una por usuario/backup), sin columnas cortadas ni desplazamiento lateral.
- **Mejora:** Tablets (≈800–1280 px, p. ej. iPad horizontal): en WOL Console el panel *Add device* pasa debajo de la tabla y el botón *Wake* ya no queda cortado; en Net Monitor el vendor/MAC se muestra solo en la fila expandida, los nombres largos se parten y la tabla cabe sin desplazarse aunque haya muchos puertos abiertos.

**WOL Console**
- **Nueva Funcionalidad:** Lee los hosts de Net Monitor (`net-monitor/hosts.json`, solo lectura): en *Add device* aparece **From Net Monitor** (solo admin con acceso a Net Monitor) para elegir un host detectado; rellena nombre, MAC, IP y categoría (computer→PC, storage→NAS, el resto→OTHER). Los ya agregados aparecen deshabilitados.
- **Nueva Funcionalidad:** Si Net Monitor conoce otra IP para la misma MAC (DHCP), la tabla muestra la IP de Net Monitor (la guardada queda tachada) y *Wake* la usa para comprobar si el equipo ya está encendido.
- **Nueva Funcionalidad:** Nuevo endpoint `GET /api/netmonitor/hosts` (requiere permiso `net` de lectura). Variables opcionales: `NET_HOSTS_FILE` (WOL) y `WOL_DEVICES_FILE` (Net Monitor).

**UPS Monitor**
- **Nueva Funcionalidad:** Los servidores NUT ahora se pueden **editar** (nombre, host y puerto) desde el botón de lápiz de la barra lateral, además de eliminarlos. Al cambiar host o puerto se reconecta de inmediato y se descartan los datos del destino anterior; el historial se conserva. Nuevo endpoint `PUT /api/servers/<id>` (solo admin).
- **Mejora:** La cabecera de los dos gráficos (voltaje y consumo) ahora tiene el mismo diseño: título a la izquierda, rangos 1h/1d/1mo/All a la derecha y la leyenda entre ambos; en pantallas de hasta 700 px, título y rangos en la primera línea y la leyenda debajo, igual en los dos. Antes el gráfico de voltaje pasaba los rangos a una segunda línea y el de consumo no.
- **Mejora:** Se pueden eliminar todos los servidores, incluido el *Local*. Sin servidores el panel muestra "No UPS found" y el resto de los módulos no se ve afectado; la lista vacía se conserva tras reiniciar y se puede volver a agregar un servidor cuando se quiera. Antes solo el servidor Local no se podía eliminar.

**Net Monitor**
- **Nueva Funcionalidad:** Nuevos tipos de dispositivo **printer** (impresora) y **tablet**. Impresoras: fabricantes (Brother, Canon, Epson, Lexmark, Xerox, Ricoh, Kyocera…), nombres de host (NPI…, LaserJet, MFC…), puertos 9100/515/631 y banners. Tablets: iPad, Galaxy Tab, Kindle, MiPad, etc.; un iPhone/Android sigue siendo *phone*. Disponibles en filtros y en la edición manual.
- **Nueva Funcionalidad:** Los hosts que están registrados en WOL Console (misma MAC) muestran la etiqueta **WOL**.
- **Mejora:** La tabla de hosts ya no se desborda en pantallas angostas: hasta 700 px se ocultan las columnas Vendor/MAC, puertos, latencia y último visto, y hasta 480 px también OS. Todo eso sigue disponible al expandir la fila (toca el nombre del host).

**Módulo de salud**
- **Nueva Funcionalidad:** Cada servicio expone `GET /api/health` (sin login: solo niveles ok/warn/fail; con sesión, el detalle) y responde 503 si algo falla. Revisa archivos de datos legibles/escribibles, espacio en disco, y por módulo: WOL (red y lista de Net Monitor), UPS (base de datos, que el historial **realmente se esté guardando**, pollers vivos, upsd respondiendo), Net Monitor (escaneo trabado, temporizador de auto-escaneo armado) y Proxmox (pollers vivos, clusters respondiendo).
- **Nueva Funcionalidad:** El Admin Panel agrega la salud de todos los módulos en una tarjeta **Salud del sistema** (se refresca cada 30 s) y en `GET /admin/api/health`.
- **Nueva Funcionalidad:** Cada módulo de la tarjeta se expande al hacer clic y muestra todo lo que se revisa: cada chequeo con su descripción, su nivel (verde/naranja/rojo) y el detalle (espacio libre, filas pendientes, error exacto, tiempo activo). Se mantiene abierto al refrescar.
- **Nueva Funcionalidad:** Nuevo comando `pi-console-health` (código de salida 0 = ok, 1 = degradado, 2 = falla; `-j` muestra el JSON), útil para cron o monitoreo externo.
- **Nueva Funcionalidad:** Fuente de la Raspberry Pi: el Admin Panel y `pi-console-health` muestran el chequeo `power` con aviso cuando la Pi registra subtensión o limitación (por fuente o cable insuficiente), sea ahora o desde el arranque. Solo aparece en una Raspberry Pi: en una VM u otro equipo no se muestra. Los eventos «desde el arranque» solo se borran al reiniciar. El instalador agrega al usuario del servicio al grupo `video` en una Pi para poder leer `vcgencmd get_throttled`.

- **Fix:** Servidores HTTP multihilo con timeout (WOL, UPS, Net Monitor, Proxmox, Admin): antes eran de un solo hilo, así que un cliente lento o colgado bloqueaba todo el módulo. Ahora cada conexión tiene su hilo y un timeout.
- **Fix:** `users.json` y `sessions.json` compartidos por 5 procesos: lectura-modificación-escritura bajo `flock`, escritura atómica (fsync + rename, archivo temporal propio) y copia `.bak` de la última versión válida. Archivos con permisos 0600. Un `users.json` dañado ya no reactiva `admin/admin`: se usa la copia `.bak` o, sin ella, no entra nadie hasta borrar el archivo.
- **Fix:** Sesiones: usuarios eliminados o con permisos reducidos pierden el acceso de inmediato (antes seguía vigente hasta 24 h); al cambiar contraseña o eliminar un usuario se cierran sus otras sesiones.
- **Fix:** Datos de cada módulo (`devices.json`, `wake_log.json`, `servers.json`, `hosts.json`, `config.json`, `clusters.json`): escritura atómica con copia `.bak`, y las altas/bajas/ediciones concurrentes ya no se pisan entre sí. `config.json` y `clusters.json` (tokens, SNMP, Pi-hole) pasan a 0600.
- **Fix:** UPS Monitor: un `ERR DATA-STALE` de upsd ya no inserta filas en cero en el historial; la base espera hasta 30 s por un bloqueo en vez de fallar; un error inesperado no mata el hilo de consulta (se reinicia solo); `/api/test` requiere admin.
- **Fix:** Net Monitor: dos escaneos simultáneos ya no pueden arrancar; el escaneo siempre libera su estado y reprograma un único temporizador (antes un reescaneo de una IP o un cambio de intervalo podían acumular temporizadores); cambiar el intervalo ya no borraba la configuración SNMP/OUI/Pi-hole; borrar un host durante un escaneo ya no reaparece; validación de IP/intervalo.
- **Fix:** WOL Console: envío del magic packet nativo (ya no depende del paquete `wakeonlan`, que no estaba declarado) y respeta el puerto del dispositivo; `/api/ping` valida el host (no acepta opciones de línea de comandos); contador de rate-limit con bloqueo y limpieza.
- **Fix:** Proxmox: `/api/test` requiere admin; el token API no se devuelve al crear un cluster; el hilo de consulta no muere por un error de lectura de configuración.

- **Fix:** UPS Monitor dejaba de guardar el historial (gráficos de consumo sin datos nuevos): aproximadamente 4 horas después de iniciar el servicio, la limpieza periódica de la base (`db_prune`) fallaba con `database table is locked` y dejaba abierta su conexión; desde ese momento todos los guardados fallaban con `database is locked` hasta reiniciar el servicio. Ahora la limpieza cierra la transacción antes de compactar el WAL, siempre libera la conexión y un error ahí ya no afecta al resto.
- **Fix:** Los servicios aceptan ráfagas de conexiones simultáneas (cola de escucha de 5 a 128): antes, 30 peticiones a la vez podían terminar con la conexión reiniciada.

- **Mejora:** Capturas de pantalla de todos los módulos (claro/oscuro, 4 resoluciones) en `docs/screenshots/` y galería en el README.

- **Fix:** Quedaban textos en español con la interfaz en inglés en WOL Console (filtro «Todos», tooltips, avisos y el «hace 8m»), UPS Monitor (tooltips y campo de servidor) y Proxmox Monitor («Conectando…», «Sin nodos»): ahora siguen el idioma elegido. Las fechas usan el formato del idioma.
- **Fix:** Mensajes de error del backend traducidos al inglés («User already exists», «Device not found», «Not found», «That host:port already exists», «Magic packet sent to …»).

- **Nueva Funcionalidad:** Nuevo comando `pi-console-resources`: memoria (RSS) y CPU de cada servicio, de nginx y RAM libre del sistema (`-w` para verlo en vivo). Sirve para decidir si hace falta mover Pi Console fuera de la Pi.

- **Seguridad:** Contraseñas: ahora se guardan con **scrypt** y una sal aleatoria por usuario (antes SHA-256 con una sal fija). Los usuarios existentes se migran solos en su próximo inicio de sesión; los respaldos antiguos siguen funcionando.
- **Seguridad:** Inicio de sesión: tras 5 intentos fallidos desde la misma IP se bloquea el acceso durante 5 minutos (respuesta 429). Cada fallo añade una pequeña espera, y un usuario inexistente tarda lo mismo que uno real. Los contadores son por servicio y se reinician al reiniciarlo.
- **Seguridad:** nginx: cabeceras `X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy` y una política `Content-Security-Policy` básica.
- **Seguridad:** users.json ausente (SEC-01): si el archivo de usuarios desaparece en una instalación ya usada, ya no se vuelve a crear el usuario `admin` / `admin`: se usa la copia `.bak` o, si no existe, nadie puede entrar hasta restaurarla. El usuario inicial solo se crea en una instalación nueva (marcador `.users-initialized` en `/var/lib/pi-console`).
- **Seguridad:** WOL Console escucha solo en `127.0.0.1`, como los demás módulos; se accede por nginx (puerto 80).
- **Seguridad:** Permisos explícitos (PVE-01): `net` y `pve` ya no se derivan del permiso WOL en cada petición. Al arrancar los servicios se migran una sola vez a valores explícitos (admin si era admin de WOL, solo lectura en otro caso) y un permiso ausente significa sin acceso. El Admin Panel muestra y edita ahora las columnas **Net Monitor** y **Proxmox**; los usuarios nuevos reciben *Sin acceso* a ambos por defecto.
- **Seguridad:** Proxmox, certificado (PVE-02): al agregar un cluster se muestra la huella SHA-256 del certificado y hay que confirmarla (botón *Probar* dos veces) antes de enviar el token; la conexión queda fijada a esa huella y falla si el certificado cambia. Los clusters existentes siguen funcionando, pero muestran el aviso «Certificado sin verificar» con un botón para fijarlo.
- **Seguridad:** Restore de NUT y nginx solo por consola (SEC-03): el panel ya no ofrece restaurar `/etc/nut` ni el sitio nginx (corrían como root vía sudo); `teleporter restore --nut` / `--nginx` sigue disponible en la consola. `teleporter.sh gui-restore` rechaza esas opciones.
- **Seguridad:** Bloqueo entre procesos (CON-01): si no se puede obtener el bloqueo de archivo, la operación falla con error en lugar de continuar sin él.

- **Mejora:** Los mensajes de instalación, actualización y desinstalación (`postinst`, `preinst`, `prerm`, `postrm`) ahora están en inglés.

## 1.1.8 — 2026-10-10

Reúne los cambios de 1.1.7 y sus revisiones (1.1.7a–1.1.7f).

**Net Monitor**
- **Nueva Funcionalidad:** Tipos de dispositivo: computer, phone, tablet, printer, router, switch, ap, storage, tv, camera, appliance, other. Columna *Type*, filtros por tipo y edición manual (`auto` vuelve a la detección).
- **Mejora:** Detección por puntajes (vendor, banner, hostname, puertos, gateway, TTL, MAC aleatoria). Los NAS ya no se detectan como Windows; Android/iOS se clasifican como phone.
- **Fix:** El tipo/OS editado ya no se pierde al terminar un escaneo.
- **Mejora:** Se muestra la MAC cuando no se detecta el vendor. Fuentes de MAC: Pi-hole, ARP local, SNMP.
- **Nueva Funcionalidad:** Fuente SNMP configurable (host, puerto, v1/2c/3, community, usuario v3, auth/privacy, timeout, botón *Test*). Lee `ipNetToMediaPhysAddress` con respaldo a `ipNetToPhysicalPhysAddress`. Las credenciales no se devuelven por la API y `config.json` queda con permisos 600.
- **Nueva Funcionalidad:** Base de vendors (OUI): `manuf` de Wireshark con descarga semanal, respaldo a `ieee-data`, actualización manual y estado en el panel.
- **Fix:** Los nombres de host de Pi-hole perdían caracteres finales al quitar `.local`.

**Proxmox Monitor**
- **Mejora de rendimiento:** Refresco más rápido: una sola llamada a `/cluster/resources` (con respaldo por nodo), conexión HTTPS persistente, sondeo de 5 s con la vista activa y 60 s en reposo, datos lentos cada 60 s, historial cada 30 s.
- **Nueva Funcionalidad:** Orden estable de nodos, orden manual (arrastrar o flechas) y pin por nodo, guardados por cluster.
- **Seguridad:** `/api/clusters` ya no expone `token_value` a usuarios viewer.

**UPS Monitor**
- **Mejora:** Layout compacto que cabe en una pantalla (probado en 1366x768, 1440x900 y 1920x1080). *Activity* pasa al fondo; los gráficos se ajustan al alto libre.
- **Fix:** Gráficos vacíos en la última hora: el cliente volvía a filtrar con el reloj del navegador y descartaba todo si difería del reloj de la Pi. Ahora el recorte usa el punto más reciente del historial.
- **Fix:** El servicio systemd se llama ahora `pi-console-ups` (antes `nut-monitor`). El nombre antiguo tapaba el servicio `upsmon` de `nut-client`: `systemctl restart nut-monitor` y `nut.target` arrancaban el dashboard en lugar de `upsmon`. Al actualizar, el `postinst` elimina la unidad antigua y, si hay `MONITOR` en `/etc/nut/upsmon.conf`, habilita y arranca el `nut-monitor` real. Logs: `journalctl -u pi-console-ups`.

**Inicio de sesión**
- **Fix:** Login directo en un módulo (WOL, UPS, Net, Proxmox) fallaba con `ME.username[0]`: `/api/login` no devolvía el usuario. Ahora lo devuelve y la interfaz tolera que falte.

**Interfaz**
- **Mejora:** Campos de entrada con fondo más oscuro y borde más marcado en tema claro y oscuro.

**Teleporter**
- **Mejora:** `/usr/local/bin/teleporter.sh` (enlace `teleporter`): `teleporter backup`, `teleporter check <archivo>`, `sudo teleporter restore <archivo> [-y] [--nut] [--nginx]`. `pi-console-backup` y `pi-console-restore` son atajos.
- **Mejora:** Respalda usuarios y sesiones, dispositivos WOL, servidores UPS e `history.db` (snapshot SQLite consistente), hosts/config de Net Monitor, clusters Proxmox, y opcionalmente configuración de NUT y sitio nginx.
- **Mejora:** `check` valida gzip, rutas seguras, SHA-256, JSON, integridad SQLite y que `users.json` no esté vacío; no modifica nada.
- **Mejora:** `restore` verifica antes de tocar, crea un snapshot en `/var/backups/pi-console/`, detiene servicios, reemplaza archivos de forma atómica (0600), valida `nginx -t` (revierte si falla), usa bloqueo contra ejecuciones simultáneas y siempre reinicia los servicios. Acepta respaldos del teleporter 1.x.
- **Mejora:** Configuración de NUT y sitio nginx se restauran solo con `--nut` / `--nginx` (desactivado por defecto; NUT se configura manualmente).
- **Mejora:** Variables de entorno de pruebas se ignoran bajo `sudo`.

**Admin Panel**
- **Nueva Funcionalidad:** Tarjeta *Backup & restore* en `/admin/`: crear (descarga automática), subir, verificar, restaurar, descargar y eliminar respaldos. Permite migrar a una instalación nueva: instalar el `.deb`, subir el respaldo y pulsar *Restore*; luego iniciar sesión con los usuarios del respaldo.
- **Nueva Funcionalidad:** La restauración corre como root mediante `/etc/sudoers.d/pi-console-teleporter` (solo `teleporter.sh gui-backup` y `gui-restore`), en la unidad `pi-console-restore`, con registro en `/var/lib/pi-console/teleporter/restore.log`.
- **Nueva Funcionalidad:** Respaldos en `/var/lib/pi-console/teleporter/` (se conservan 5; subidas se borran tras 24 h). Límite de subida: 200 MB.
- **Nueva Funcionalidad:** Endpoints (solo admin): `GET /api/teleporter`, `POST /api/teleporter/{backup,upload,check,restore}`, `GET /api/teleporter/download/<archivo>`, `DELETE /api/teleporter/<archivo>`.
- **Nueva Funcionalidad:** nginx `/admin/`: cuerpos de hasta 200 MB, sin buffer de subida, timeouts de 300 s.

- **Mejora:** Nueva dependencia: `sudo`. Nuevos `Suggests`: `ieee-data`, `snmp`.
- **Mejora:** `postinst` crea el directorio del teleporter y la regla sudo (validada con `visudo -c`); `postrm` la elimina.
- **Mejora:** Los datos de usuario (`clusters.json`, `hosts.json`, `config.json`) se conservan al actualizar.

- **Conocido:** En pantallas de ~390 px el UPS Monitor desborda horizontalmente.
- **Conocido:** El banner del `postinst` siempre muestra el usuario inicial `admin / admin`, también al actualizar.
