#!/usr/bin/env python3
"""
WAN Monitor — salud de la conexión a Internet: latencia, pérdida, cortes, IP pública y velocidad / Internet connection health
"""
# WAN Monitor (puerto 8088): vigila la conexión a Internet desde este equipo. Cada pocos segundos hace ping (o conexión TCP) a varios destinos
# y a la puerta de enlace, mide la resolución de un nombre DNS y guarda latencia, jitter y pérdida; registra los cortes (con su duración y si el fallo
# fue de la red local o de Internet), avisa si cambia la IP pública y mide la velocidad de bajada y subida con un servidor compatible con Cloudflare.
#
# Flujo de datos:
#   un hilo «sonda» → probe_round() → WanState guarda la última lectura, el historial y los cortes → la página la pide a /api/wan.
#   Otro hilo revisa cada minuto si toca medir la velocidad según la programación (o si alguien pulsó «Medir ahora»).
#
# Notas: la velocidad es la que ESTE equipo alcanza hacia el servidor de prueba; una máquina pequeña puede quedar por debajo de una línea gigabit. Durante la
# medición se pausan las sondas para que la línea saturada no cuente como un corte. La medición consume ancho de banda: por eso es programable.
#
# Estructura: configuración · sondas · velocidad · estado, cortes e historial · hilos · salud · HTTP.
# EN: WAN Monitor (port 8088): watches the Internet connection from this machine. Every few seconds it pings (or opens a TCP connection to) several
#     targets and the gateway, times a DNS name resolution and stores latency, jitter and loss; it records outages (with duration and whether the
#     local network or the Internet failed), warns when the public IP changes and measures download and upload speed against a Cloudflare-compatible server.
#
#     Data flow:
#       one "probe" thread → probe_round() → WanState keeps the last reading, the history and the outages → the page requests it from /api/wan.
#       Another thread checks every minute whether a speed test is due by schedule (or whether someone pressed "Measure now").
#
#     Notes: the speed is what THIS machine reaches toward the test server; a small machine can fall below a gigabit line. Probes are paused during
#     the measurement so the saturated line does not count as an outage. The measurement uses bandwidth: that is why it is schedulable.
#
#     Structure: configuration · probes · speed · state, outages and history · threads · health · HTTP.
import http.client
import ipaddress
import json
import logging
import os
import re
import shutil
import socket
import sqlite3
import ssl
import subprocess
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ThreadingHTTPServer.request_queue_size = 128
from collections import deque as _deque
from pathlib import Path
from urllib.parse import parse_qs, urlparse

sys.path.insert(0, str(Path(__file__).parent.parent / "auth"))
import auth

sys.path.insert(0, str(Path(__file__).parent))
import router as rtr
import stats as wst

HOST       = "127.0.0.1"
PORT       = 8088
STATIC_DIR = Path(__file__).parent / "static"
DATA_DIR   = auth.module_dir("wan-monitor")
LEGACY_FILES = ()
DATA_FILE  = DATA_DIR / "wan.json"
STATE_FILE = DATA_DIR / "state.json"                       # last known public IP and when it changed
HIST_KEEP  = auth.keep_days("WAN_KEEP_DAYS", 30) * 86400
_HIST_MAX  = 1500                                          # ~12 h at 30 s
DOWN_AFTER = 2                                             # failed rounds in a row before declaring an outage
IP_EVERY   = 600                                           # public IP check period (s)
_STARTED   = time.time()

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s", datefmt="%H:%M:%S")
log = logging.getLogger("wan")

# ─── Configuración ────────────────────────────────────────────────────────────
DEFAULTS = {
    "targets": [{"host": "1.1.1.1", "kind": "ping"}, {"host": "8.8.8.8", "kind": "ping"}, {"host": "9.9.9.9", "kind": "ping"}],
    "gateway": "auto",                    # "auto" (default route), "" (off) or an IP
    "dns_name": "cloudflare.com",         # name resolved with the system resolver ("" = off)
    "interval": 30,                       # seconds between rounds
    "ip_url": "https://api.ipify.org",    # returns the public IP as plain text ("" = off)
    "router": {"enabled": False, "type": "huawei", "host": "", "port": 80, "https": False, "user": "admin", "password": "", "interface": "wan", "every": 30},
    "speed": {"enabled": True, "every_minutes": 720, "down_url": "https://speed.cloudflare.com/__down", "up_url": "https://speed.cloudflare.com/__up",
              "seconds": 8, "streams": 4, "upload": True, "engine": "builtin", "plan_down": 0, "plan_up": 0},
}
_cfg_lock = threading.RLock()
# Motores de la prueba de velocidad: el integrado (Cloudflare) y, si están instalados, los programas Ookla y LibreSpeed para contrastar.
# EN: Speed test engines: the built-in one (Cloudflare) and, when installed, the Ookla and LibreSpeed programs to cross-check.
ENGINES = {"builtin": None, "ookla": "speedtest", "librespeed": "librespeed-cli"}
def engines_available():
    return {k: (b is None or bool(shutil.which(b))) for k, b in ENGINES.items()}

def _https_url(u, what, resolve=True):
    u = str(u or "").strip()
    p = urlparse(u)
    if p.scheme != "https" or p.username or p.password or not (auth.valid_host(p.hostname or "") and auth.valid_target(p.hostname, resolve=resolve)): raise ValueError(f"{what} must be an https:// address")
    try: _ = p.port          # validates the port: raises ValueError if invalid
    except ValueError: raise ValueError(f"Invalid port in {what}")
    if len(u) > 300 or re.search(r"[\x00-\x20\x7f]", u): raise ValueError(f"Invalid {what}")
    return u

def _int(v, lo, hi, what):
    try: v = int(v)
    except (TypeError, ValueError): raise ValueError(f"Invalid {what}")
    if not lo <= v <= hi: raise ValueError(f"{what} must be {lo}-{hi}")
    return v

# Ajustes del router. La clave solo se cambia si llega una nueva (vacía = conservar la guardada; clear_password = borrarla) y NUNCA se devuelve al navegador.
# EN: Router settings. The password changes only when a new one arrives (empty = keep the stored one; clear_password = delete it) and is NEVER sent to the browser.
def _validate_router(new, cur, resolve=True):
    r = dict(DEFAULTS["router"]); r.update(cur if isinstance(cur, dict) else {})
    if isinstance(new, dict):
        for k in ("enabled", "type", "host", "port", "https", "user", "interface", "every"):
            if k in new: r[k] = new[k]
        if new.get("clear_password") is True: r["password"] = ""
        elif isinstance(new.get("password"), str) and new["password"]: r["password"] = new["password"]
    r["enabled"], r["https"] = bool(r.get("enabled")), bool(r.get("https"))
    if r.get("type") not in rtr.TYPES: raise ValueError("Unknown router type")
    host = str(r.get("host") or "").strip()
    if host and not (auth.valid_host(host) and auth.valid_target(host, resolve=resolve)): raise ValueError("Invalid router address")
    r["host"] = host
    r["port"] = _int(r.get("port", 80), 1, 65535, "Router port")
    user = str(r.get("user") or "").strip()
    if len(user) > 64 or re.search(r"[\x00-\x1f\x7f]", user): raise ValueError("Invalid router user")
    r["user"] = user
    pw = r.get("password") if isinstance(r.get("password"), str) else ""
    if len(pw) > 128 or re.search(r"[\x00-\x1f\x7f]", pw): raise ValueError("Invalid router password")
    r["password"] = pw
    itf = str(r.get("interface") or "wan").strip()
    if not re.fullmatch(r"[A-Za-z0-9_.\-]{1,32}", itf): raise ValueError("Invalid interface name")
    r["interface"] = itf
    r["every"] = _int(r.get("every", 30), 10, 300, "Router check interval")
    if r["enabled"] and not r["password"]: raise ValueError("The router needs a password to be checked")
    # La huella del certificado nunca viene del formulario: guardar los ajustes del router la borra y se vuelve a aprender.
    # EN: The certificate fingerprint never comes from the form: saving the router settings clears it and it is learned again.
    r.pop("tls_pin", None)
    return r

# Huella guardada válida: {"addr": "host:puerto", "fp": sha256 en hex}. / EN: Valid stored fingerprint: {"addr": "host:port", "fp": hex sha256}.
def _valid_pin(p):
    return (isinstance(p, dict) and isinstance(p.get("addr"), str) and 0 < len(p["addr"]) <= 300
            and isinstance(p.get("fp"), str) and re.fullmatch(r"[0-9a-f]{64}", p["fp"]) is not None)

# Guarda la huella aprendida en la primera conexión HTTPS al router (solo si sigue siendo la misma dirección y no hay otra).
# EN: Stores the fingerprint learned on the first HTTPS connection to the router (only if the address is the same and none is set).
def learn_router_pin(pin):
    if not _valid_pin(pin): return
    with _cfg_lock:
        cfg = load_config(); cur = cfg["router"].get("tls_pin")
        if _valid_pin(cur) and cur["addr"] == pin["addr"]: return
        cfg["router"]["tls_pin"] = {"addr": pin["addr"], "fp": pin["fp"]}; save_config(cfg)
    log.info(f"router {pin['addr']}: certificate fingerprint pinned ({pin['fp'][:16]}…)")

# La configuración que ve el navegador: sin la clave del router, con un aviso de si hay una guardada.
# EN: The configuration the browser sees: without the router password, with a flag telling whether one is stored.
def public_config(cfg):
    out = json.loads(json.dumps(cfg)); out["router"].pop("password", None); out["router"].pop("tls_pin", None)
    out["router"]["has_password"] = bool(cfg["router"].get("password"))
    return out

# Combina lo recibido con lo guardado y valida cada campo.
# EN: Merge what arrived with what is stored and validate every field.
def validate(body: dict, current=None, resolve=True) -> dict:
    cfg = json.loads(json.dumps(current or DEFAULTS))
    for k in ("targets", "gateway", "dns_name", "interval", "ip_url"):
        if k in body: cfg[k] = body[k]
    if isinstance(body.get("speed"), dict):
        sb = dict(body["speed"])
        # Antes el período se guardaba en horas (every_hours). Si llega así y no trae minutos, se convierte; los minutos mandan si vienen los dos.
        # EN: The period used to be stored in hours (every_hours). If it arrives that way without minutes it is converted; minutes win if both come.
        if "every_hours" in sb and "every_minutes" not in sb: sb["every_minutes"] = _int(sb["every_hours"], 0, 720, "Speed test period") * 60
        sb.pop("every_hours", None)
        cfg["speed"].update(sb)
    cfg["router"] = _validate_router(body.get("router"), cfg.get("router"), resolve)
    tg = cfg["targets"]
    if not isinstance(tg, list) or not 1 <= len(tg) <= 6: raise ValueError("Between 1 and 6 targets")
    out = []
    for t in tg:
        if not isinstance(t, dict): raise ValueError("Invalid target")  # noqa: TRY004 - validación de entrada; quien llama espera ValueError / EN: input validation, callers expect ValueError
        host, kind = str(t.get("host") or "").strip(), str(t.get("kind") or "ping")
        if not auth.valid_host(host): raise ValueError("Invalid target host")
        if kind not in ("ping", "tcp"): raise ValueError("Invalid target type")
        item = {"host": host, "kind": kind}
        if kind == "tcp": item["port"] = _int(t.get("port", 443), 1, 65535, "port")
        if any(o["host"] == host and o["kind"] == kind and o.get("port") == item.get("port") for o in out): raise ValueError("Repeated target")
        out.append(item)
    cfg["targets"] = out
    gw = str(cfg.get("gateway") or "").strip()
    if gw not in ("", "auto"):
        try: ipaddress.ip_address(gw)
        except ValueError: raise ValueError("Gateway must be auto, empty or an IP")
    cfg["gateway"] = gw
    dn = str(cfg.get("dns_name") or "").strip()
    if dn and not auth.valid_host(dn): raise ValueError("Invalid DNS name")
    cfg["dns_name"] = dn
    cfg["interval"] = _int(cfg["interval"], 10, 300, "Interval")
    iu = str(cfg.get("ip_url") or "").strip()
    cfg["ip_url"] = _https_url(iu, "IP address service", resolve) if iu else ""
    sp = cfg["speed"]
    sp["enabled"], sp["upload"] = bool(sp.get("enabled")), bool(sp.get("upload"))
    if sp.get("engine", "builtin") not in ENGINES: raise ValueError("Unknown speed test engine")
    sp["engine"] = sp.get("engine", "builtin")
    sp.pop("every_hours", None)
    sp["every_minutes"] = _int(sp.get("every_minutes", 720), 0, 43200, "Speed test period")        # minutes, 0 = never
    if 0 < sp["every_minutes"] < 5: raise ValueError("Speed test period: at least 5 minutes (0 = never)")
    sp["seconds"] = _int(sp.get("seconds", 8), 3, 20, "Speed test duration")
    sp["streams"] = _int(sp.get("streams", 4), 1, 8, "Streams")
    sp["plan_down"] = _int(sp.get("plan_down", 0), 0, 100000, "Contracted download speed")      # Mb/s, 0 = not set
    sp["plan_up"] = _int(sp.get("plan_up", 0), 0, 100000, "Contracted upload speed")
    sp["down_url"] = _https_url(sp.get("down_url"), "Download address", resolve)
    sp["up_url"] = _https_url(sp.get("up_url"), "Upload address", resolve)
    return cfg

# ES: Se lee en cada ronda, petición y chequeo de salud: aquí NO se resuelven nombres por DNS (cada lectura generaba consultas a api.ipify.org y speed.cloudflare.com
#     al DNS de la red, decenas de miles al día). La comprobación con DNS se hace al guardar y justo antes de conectarse (_url_safe).
# EN: Read on every round, request and health check: names are NOT resolved here (every read sent queries for api.ipify.org and speed.cloudflare.com to the
#     network's DNS, tens of thousands a day). The check with DNS is done when saving and right before connecting (_url_safe).
def load_config() -> dict:
    cur = auth.read_json(DATA_FILE, {}, dict)
    try: cfg = validate(cur, resolve=False) if cur else validate({}, resolve=False)
    except ValueError as e:
        log.warning(f"stored configuration invalid ({e}); using defaults"); return validate({}, resolve=False)
    pin = cur.get("router", {}).get("tls_pin") if isinstance(cur.get("router"), dict) else None
    if _valid_pin(pin): cfg["router"]["tls_pin"] = pin                  # only from storage, learned by the router thread
    return cfg

def save_config(cfg: dict):
    with _cfg_lock: auth.write_json(DATA_FILE, cfg)

# Puerta de enlace IPv4 predeterminada, leída de /proc/net/route.
# EN: Default IPv4 gateway, read from /proc/net/route.
def default_gateway(path="/proc/net/route"):
    try:
        for line in Path(path).read_text().splitlines()[1:]:
            f = line.split()
            if len(f) >= 4 and f[1] == "00000000" and int(f[3], 16) & 2:
                return socket.inet_ntoa(int(f[2], 16).to_bytes(4, "little"))
    except (OSError, ValueError): pass
    return None

# ─── Sondas ───────────────────────────────────────────────────────────────────
_RE_SENT = re.compile(r"(\d+) packets transmitted, (\d+) (?:packets )?received")
_RE_RTT  = re.compile(r"= ([\d.]+)/([\d.]+)/([\d.]+)/([\d.]+) ms")

# Ping con 3 paquetes. Devuelve {sent, recv, loss, rtt, jitter}; nunca lanza excepción.
# EN: Ping with 3 packets. Returns {sent, recv, loss, rtt, jitter}; never raises.
def ping(host, count=3, timeout=2):
    exe = shutil.which("ping")
    res = {"sent": count, "recv": 0, "loss": 100.0, "rtt": None, "jitter": None}
    if not exe: res["error"] = "ping not installed"; return res
    try:
        r = subprocess.run([exe, "-n", "-q", "-c", str(count), "-W", str(timeout), host], capture_output=True, text=True, timeout=count * (timeout + 1) + 3, check=False)
    except (subprocess.TimeoutExpired, OSError) as e:
        res["error"] = type(e).__name__; return res
    out = r.stdout or ""
    s = _RE_SENT.search(out)
    if s:
        res["sent"], res["recv"] = int(s.group(1)), int(s.group(2))
        res["loss"] = round(100.0 * (res["sent"] - res["recv"]) / max(1, res["sent"]), 1)
    m = _RE_RTT.search(out)
    if m and res["recv"]: res["rtt"], res["jitter"] = round(float(m.group(2)), 2), round(float(m.group(4)), 2)
    return res

# Conexión TCP cronometrada (tres intentos).
# EN: Timed TCP connection (three attempts).
def tcp_probe(host, port, count=3, timeout=2):
    ts = []
    for _ in range(count):
        t0 = time.perf_counter()
        try:
            with socket.create_connection((host, port), timeout=timeout): pass
            ts.append((time.perf_counter() - t0) * 1000)
        except OSError: pass
        time.sleep(0.05)
    res = {"sent": count, "recv": len(ts), "loss": round(100.0 * (count - len(ts)) / count, 1), "rtt": None, "jitter": None}
    if ts:
        avg = sum(ts) / len(ts); res["rtt"] = round(avg, 2); res["jitter"] = round((sum((x - avg) ** 2 for x in ts) / len(ts)) ** 0.5, 2)
    return res

# Tiempo de resolución de un nombre con el DNS del sistema (en un hilo, para no quedar colgado si el DNS no responde).
# EN: Resolution time of a name with the system DNS (in a thread, so it does not hang if the DNS does not answer).
def dns_probe(name, timeout=4):
    box = {}
    def run():
        t0 = time.perf_counter()
        try: socket.getaddrinfo(name, 443, proto=socket.IPPROTO_TCP); box["ms"] = round((time.perf_counter() - t0) * 1000, 1)
        except OSError: box["fail"] = True
    t = threading.Thread(target=run, daemon=True); t.start(); t.join(timeout)
    return box.get("ms")

def _probe_one(t):
    r = ping(t["host"]) if t["kind"] == "ping" else tcp_probe(t["host"], t["port"])
    r.update(host=t["host"], kind=t["kind"], ok=r["recv"] > 0)
    if t["kind"] == "tcp": r["port"] = t["port"]
    return r

def _avg(vals):
    v = [x for x in vals if x is not None]
    return round(sum(v) / len(v), 2) if v else None

# Una ronda: todos los destinos y la puerta de enlace en paralelo, más el DNS. «up» = al menos un destino de Internet respondió.
# EN: One round: every target and the gateway in parallel, plus DNS. "up" = at least one Internet target answered.
def probe_round(cfg, gw_ip):
    jobs = list(cfg["targets"]) + ([{"host": gw_ip, "kind": "ping", "gateway": True}] if gw_ip else [])
    results, th = [None] * len(jobs), []
    def work(i, t): results[i] = _probe_one(t)
    for i, t in enumerate(jobs):
        x = threading.Thread(target=work, args=(i, t), daemon=True); x.start(); th.append(x)
    dns = [None]
    if cfg["dns_name"]:
        d = threading.Thread(target=lambda: dns.__setitem__(0, dns_probe(cfg["dns_name"])), daemon=True); d.start(); th.append(d)
    for x in th: x.join(30)
    for i, r in enumerate(results):
        if r is None: results[i] = {"host": jobs[i]["host"], "kind": jobs[i]["kind"], "sent": 3, "recv": 0, "loss": 100.0, "rtt": None, "jitter": None, "ok": False}
        if jobs[i].get("gateway"): results[i]["gateway"] = True
    net = [r for r in results if not r.get("gateway")]
    gw = next((r for r in results if r.get("gateway")), None)
    ok = [r for r in net if r["ok"]]
    return {"ts": int(time.time()), "up": bool(ok), "targets": net, "gateway": gw,
            "rtt": _avg([r["rtt"] for r in ok]), "jitter": _avg([r["jitter"] for r in ok]), "loss": _avg([r["loss"] for r in net]),
            "gw": gw["rtt"] if gw else None, "dns": dns[0]}

# ─── Velocidad ────────────────────────────────────────────────────────────────
def _conn(url, timeout=10):
    p = urlparse(url)
    c = http.client.HTTPSConnection(p.hostname, p.port or 443, timeout=timeout, context=ssl.create_default_context())
    return c, (p.path or "/")

# Latencia hacia el servidor de prueba: pide 0 bytes por una conexión ya abierta y toma el menor tiempo.
# EN: Latency to the test server: ask for 0 bytes over an already-open connection and take the lowest time.
def speed_ping(cfg):
    c, path = _conn(cfg["speed"]["down_url"])
    best = None
    try:
        for i in range(4):
            t0 = time.perf_counter()
            c.request("GET", path + "?bytes=0", headers={"User-Agent": "LabTower-WAN"}); r = c.getresponse(); r.read()
            dt = (time.perf_counter() - t0) * 1000
            if i and (best is None or dt < best): best = dt
    finally: c.close()
    return round(best, 1) if best else None

# Bajada: varios flujos leen del servidor hasta que se cumple el tiempo; Mb/s = bits recibidos / segundos.
# EN: Download: several streams read from the server until the time is up; Mb/s = bits received / seconds.
def speed_down(cfg):
    sp = cfg["speed"]; total, lock, end = [0], threading.Lock(), time.time() + sp["seconds"]
    why = []                                                  # first reason a stream gave up (shown instead of a generic error)
    base = "https://" + (urlparse(sp["down_url"]).hostname or "")
    hdr = {"User-Agent": "Mozilla/5.0 (LabTower-WAN)", "Accept": "*/*", "Referer": base + "/", "Origin": base}
    def work():
        got = 0
        try:
            while time.time() < end:
                c, path = _conn(sp["down_url"], 15)
                try:
                    c.request("GET", path + "?bytes=25000000", headers=hdr); r = c.getresponse()
                    if r.status != 200:
                        why.append(f"HTTP {r.status} from the download address"); break
                    buf = bytearray(262144)
                    while time.time() < end:
                        n = r.readinto(buf)
                        if not n: break
                        got += n
                finally: c.close()
        except (OSError, http.client.HTTPException) as e: why.append(f"{type(e).__name__}: {e}"[:120])
        with lock: total[0] += got
    t0 = time.perf_counter(); th = [threading.Thread(target=work, daemon=True) for _ in range(sp["streams"])]
    for x in th: x.start()
    for x in th: x.join(sp["seconds"] + 20)
    el = max(0.001, time.perf_counter() - t0)
    if not total[0] and why: raise RuntimeError(why[0])
    return round(total[0] * 8 / el / 1e6, 1) if total[0] else None

# Subida: varios flujos envían bloques de 2 MB al servidor hasta que se cumple el tiempo.
# EN: Upload: several streams send 2 MB blocks to the server until the time is up.
def speed_up(cfg):
    sp = cfg["speed"]; total, lock, end = [0], threading.Lock(), time.time() + sp["seconds"]
    block = bytes(2 * 1024 * 1024)
    why = []
    def work():
        got = 0
        try:
            c, path = _conn(sp["up_url"], 15)
            try:
                while time.time() < end:
                    c.request("POST", path, body=block, headers={"User-Agent": "LabTower-WAN", "Content-Type": "application/octet-stream"})
                    r = c.getresponse(); r.read()
                    if r.status >= 400:
                        why.append(f"HTTP {r.status} from the upload address"); break
                    got += len(block)
            finally: c.close()
        except (OSError, http.client.HTTPException) as e: why.append(f"{type(e).__name__}: {e}"[:120])
        with lock: total[0] += got
    t0 = time.perf_counter(); th = [threading.Thread(target=work, daemon=True) for _ in range(sp["streams"])]
    for x in th: x.start()
    for x in th: x.join(sp["seconds"] + 20)
    el = max(0.001, time.perf_counter() - t0)
    if not total[0] and why: raise RuntimeError(why[0])
    return round(total[0] * 8 / el / 1e6, 1) if total[0] else None

def _run_tool(cmd, timeout):
    env = dict(os.environ, HOME=str(DATA_DIR))                 # Ookla keeps its licence acceptance in $HOME/.config
    try: r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, env=env, check=False)
    except subprocess.TimeoutExpired: raise RuntimeError(f"{cmd[0]} timed out")
    if r.returncode != 0: raise RuntimeError((r.stderr or r.stdout or f"{cmd[0]} exited with {r.returncode}").strip().splitlines()[-1][:160])
    try: return json.loads(r.stdout)
    except ValueError: raise RuntimeError(f"{cmd[0]} did not return JSON")

def _g(d, *keys):
    for k in keys:
        d = d.get(k) if isinstance(d, dict) else None
    return d

def _mbps(v, scale):
    try: return round(float(v) * scale, 1)
    except (TypeError, ValueError): return None

# Ookla Speedtest CLI oficial: «bandwidth» viene en bytes por segundo.
# EN: Official Ookla Speedtest CLI: "bandwidth" is in bytes per second.
def speed_ookla(cfg, res):
    j = _run_tool([shutil.which("speedtest") or "speedtest", "--accept-license", "--accept-gdpr", "-f", "json"], 150)
    res["down"], res["up"] = _mbps(_g(j, "download", "bandwidth"), 8 / 1e6), _mbps(_g(j, "upload", "bandwidth"), 8 / 1e6)
    res["ping"] = _mbps(_g(j, "ping", "latency"), 1)
    sv = j.get("server") if isinstance(j.get("server"), dict) else {}
    res["server"] = str(sv.get("host") or sv.get("name") or "Ookla")[:80]
    if res["down"] is None: res["error"] = "Ookla returned no download result"

# LibreSpeed CLI: devuelve una lista; «download» y «upload» ya vienen en Mb/s.
# EN: LibreSpeed CLI: returns a list; "download" and "upload" are already in Mb/s.
def speed_librespeed(cfg, res):
    sp = cfg["speed"]
    cmd = [shutil.which("librespeed-cli") or "librespeed-cli", "--json", "--duration", str(sp["seconds"])] + ([] if sp["upload"] else ["--no-upload"])
    j = _run_tool(cmd, 40 + 3 * sp["seconds"])
    j = j[0] if isinstance(j, list) and j else j
    if not isinstance(j, dict): raise RuntimeError("librespeed-cli returned no result")  # noqa: TRY004 - fallo de la herramienta, no de tipos / EN: a tool failure, not a type error
    res["down"], res["up"] = _mbps(j.get("download"), 1), (_mbps(j.get("upload"), 1) if sp["upload"] else None)
    res["ping"] = _mbps(j.get("ping"), 1)
    sv = j.get("server") if isinstance(j.get("server"), dict) else {}
    res["server"] = (urlparse(str(sv.get("url") or "")).hostname or str(sv.get("name") or "LibreSpeed"))[:80]
    if not res["down"]: res["error"] = "LibreSpeed returned no download result"

def run_speedtest(cfg) -> dict:
    eng = cfg["speed"].get("engine", "builtin")
    if eng != "builtin":
        res = {"ts": int(time.time()), "down": None, "up": None, "ping": None, "server": eng, "error": None}
        try:
            if not shutil.which(ENGINES[eng]): raise RuntimeError(f"{ENGINES[eng]} is not installed")
            (speed_ookla if eng == "ookla" else speed_librespeed)(cfg, res)
        except Exception as e: res["error"] = f"{e}"[:200]  # noqa: BLE001 - el error queda guardado y se muestra / the error is kept and shown
        return res
    return _builtin_speedtest(cfg)

def _builtin_speedtest(cfg) -> dict:
    res = {"ts": int(time.time()), "down": None, "up": None, "ping": None, "server": urlparse(cfg["speed"]["down_url"]).hostname, "error": None}
    try:
        if not (_url_safe(cfg["speed"]["down_url"]) and _url_safe(cfg["speed"]["up_url"])): raise RuntimeError("A test address points at this machine or a link-local address")
        res["ping"] = speed_ping(cfg)
        res["down"] = speed_down(cfg)
        if res["down"] is None: res["error"] = "No data received from the test server"
        elif cfg["speed"]["upload"]:
            try: res["up"] = speed_up(cfg)
            except Exception as e: log.warning(f"upload test failed: {e}")      # the download result is still worth keeping  # noqa: BLE001 - se registra y el servicio sigue / logged, the service keeps running
    except Exception as e:  # noqa: BLE001 - el error queda guardado y se muestra / the error is kept and shown
        res["error"] = f"{type(e).__name__}: {e}"[:200]
    return res

# ─── IP pública ───────────────────────────────────────────────────────────────
# Antes de conectar se resuelve el nombre UNA vez y se rechaza si apunta a esta máquina o a una dirección de enlace local (SSRF), aunque se haya guardado antes.
# EN: Before connecting, the name is resolved ONCE and refused if it points at this machine or a link-local address (SSRF), even if it was saved earlier.
def _url_safe(url):
    h = urlparse(url).hostname
    return bool(h) and auth.valid_target(h)

def fetch_public_ip(url):
    if not _url_safe(url): return None
    c, path = _conn(url, 6)
    try:
        c.request("GET", path, headers={"User-Agent": "LabTower-WAN", "Accept": "text/plain"}); r = c.getresponse(); raw = r.read(256)
        if r.status != 200: return None
        return str(ipaddress.ip_address(raw.decode("ascii", "ignore").strip()))
    except (OSError, http.client.HTTPException, ValueError): return None
    finally: c.close()

# ─── Estado, cortes e historial ───────────────────────────────────────────────
class WanState:
    def __init__(self):
        self.lock = threading.RLock()
        self.last, self.fails, self.down_since, self.scope = None, 0, None, None
        self.history = _deque(maxlen=_HIST_MAX)
        self.ip, self.ip_changed, self.ip_checked, self.ip_prev = None, None, 0, None
        self.speed_running, self.speed_started, self.speed_last = False, 0, 0
        self.wake = threading.Event()
        self.gw = None
        self.router, self.router_wake, self.router_test = None, threading.Event(), 0
        self.speed_low = None          # tests in a row under 70 % of the plan (None until the history is read)

S = WanState()

def _db(sql, args=(), fetch=False):
    c = auth.metrics_conn()
    try:
        cur = c.execute(sql, args); rows = cur.fetchall() if fetch else None; c.commit(); return rows
    finally: c.close()

def store_sample(r):
    try: _db("INSERT OR REPLACE INTO wan_samples (ts,up,rtt,loss,jitter,gw,dns) VALUES (?,?,?,?,?,?,?)", (r["ts"], 1 if r["up"] else 0, r["rtt"], r["loss"], r["jitter"], r["gw"], r["dns"]))
    except Exception as e: log.warning(f"could not store the sample: {e}")  # noqa: BLE001 - se registra y el servicio sigue / logged, the service keeps running

def tkey(t):
    """Label of a target in the history: the host for ping, tcp:host:port for TCP."""
    return t["host"] if t.get("kind") != "tcp" else f"tcp:{t['host']}:{t.get('port')}"

def store_targets(r):
    rows = [(tkey(t), r["ts"], t.get("rtt"), t.get("loss"), 1 if t.get("ok") else 0) for t in r.get("targets", [])]
    if not rows: return
    try:
        c = auth.metrics_conn()
        try: c.executemany("INSERT OR REPLACE INTO wan_targets (host,ts,rtt,loss,ok) VALUES (?,?,?,?,?)", rows); c.commit()
        finally: c.close()
    except Exception as e: log.warning(f"could not store the target samples: {e}")  # noqa: BLE001 - se registra y el servicio sigue / logged, the service keeps running

def history_window(range_: str, prev: bool = False):
    """(since, until) of a range. prev=True gives the period just before it (same length) so charts can compare the two; "all" has none."""
    now, span = int(time.time()), RANGE_SECS.get(range_)
    if prev: return ((now - 2 * span, now - span) if span else None)
    return (now - span if span else 0, now + 1)

def history_range(range_: str, prev: bool = False) -> list:
    win = history_window(range_, prev)
    if win is None: return []
    rows = _db("SELECT ts,up,rtt,loss,jitter,gw,dns FROM wan_samples WHERE ts >= ? AND ts < ? ORDER BY ts", (win[0], win[1]), fetch=True)
    step = 1 if len(rows) <= RANGE_POINTS else -(-len(rows) // RANGE_POINTS)
    def avg(grp, k):
        v = [r[k] for r in grp if r[k] is not None]
        return round(sum(v) / len(v), 2) if v else None
    out = []
    for i in range(0, len(rows), step):
        g = rows[i:i + step]
        out.append({"ts": g[len(g) // 2][0], "up": min(r[1] for r in g), "rtt": avg(g, 2), "loss": avg(g, 3), "jitter": avg(g, 4), "gw": avg(g, 5), "dns": avg(g, 6)})
    return out
RANGE_SECS = {"1h": 3600, "1d": 86400, "1w": 604800, "1mo": 2592000}
RANGE_POINTS = 600

# Pruebas de velocidad de un rango (sin las fallidas), para el gráfico de velocidad. Son pocas por día: no se reducen.
# EN: Speed tests of a range (failed ones left out) for the speed chart. There are few per day, so they are not reduced.
def speed_range(range_: str, prev: bool = False) -> list:
    win = history_window(range_, prev)
    if win is None: return []
    rows = _db("SELECT ts,down,up,ping FROM wan_speed WHERE ts >= ? AND ts < ? AND error IS NULL AND (down IS NOT NULL OR up IS NOT NULL) ORDER BY ts DESC LIMIT ?",
               (win[0], win[1], RANGE_POINTS), fetch=True)
    return [{"ts": a, "down": b, "up": c, "ping": d} for a, b, c, d in reversed(rows)]

def uptime():
    now, out = int(time.time()), {}
    for k, secs in (("24h", 86400), ("7d", 604800), ("30d", 2592000)):
        try:
            n, up = _db("SELECT COUNT(*), COALESCE(SUM(up),0) FROM wan_samples WHERE ts >= ?", (now - secs,), fetch=True)[0]
            out[k] = round(100.0 * up / n, 3) if n else None
        except (sqlite3.Error, OSError): out[k] = None
    return out

# ─── Estadísticas: percentiles, destinos, velocidad contra el plan y disponibilidad ───
# Se calculan sobre el historial guardado y se guardan 60 s en memoria (la página consulta cada pocos segundos).
# EN: ─── Statistics: percentiles, targets, speed against the plan and availability ───
#     Computed over the stored history and kept 60 s in memory (the page asks every few seconds).
_stats_cache = [0, None]

def wan_stats(cfg):
    now = int(time.time())
    if _stats_cache[1] is not None and now - _stats_cache[0] < 60: return _stats_cache[1]
    out = {"latency": {}, "targets": {}, "speed": None, "avail": {}}
    try:
        first = (_db("SELECT MIN(ts) FROM wan_samples", fetch=True) or [[None]])[0][0] or now
        for k, w in (("24h", 86400), ("7d", 604800), ("30d", 2592000)):
            rtts = [r[0] for r in _db("SELECT rtt FROM wan_samples WHERE ts >= ? AND up = 1 AND rtt IS NOT NULL", (now - w,), fetch=True)]
            out["latency"][k] = wst.latency_stats(rtts)
            outs = _db("SELECT start,end,scope FROM wan_outages WHERE COALESCE(end, ?) >= ?", (now, now - w), fetch=True)
            out["avail"][k] = wst.outage_stats(outs, now, w, first)
        for k, w in (("24h", 86400), ("7d", 604800)):
            out["targets"][k] = wst.target_stats(_db("SELECT host,rtt,loss,ok FROM wan_targets WHERE ts >= ?", (now - w,), fetch=True))
        sp = cfg["speed"]
        rows = _db("SELECT ts,down,up,error FROM wan_speed WHERE ts >= ? ORDER BY ts", (now - 30 * 86400,), fetch=True)
        out["speed"] = wst.speed_stats(rows, sp.get("plan_down"), sp.get("plan_up"), now, lambda t: time.localtime(t).tm_hour)
    except Exception as e:  # noqa: BLE001 - se registra y el servicio sigue / logged, the service keeps running
        log.warning(f"could not compute the statistics: {e}")
    _stats_cache[0], _stats_cache[1] = now, out
    return out

def recent_outages(limit=15):
    try:
        rows = _db("SELECT o.start,o.end,o.scope,t.start IS NOT NULL FROM wan_outages o LEFT JOIN wan_traces t ON t.start = o.start ORDER BY o.start DESC LIMIT ?", (limit,), fetch=True)
        return [{"start": a, "end": b, "scope": s, "trace": bool(tr)} for a, b, s, tr in rows]
    except (sqlite3.Error, OSError): return []

def recent_speed(limit=40):
    try:
        rows = _db("SELECT ts,down,up,ping,server,error FROM wan_speed ORDER BY ts DESC LIMIT ?", (limit,), fetch=True)
        return [{"ts": a, "down": b, "up": c, "ping": d, "server": e, "error": f} for a, b, c, d, e, f in reversed(rows)]
    except (sqlite3.Error, OSError): return []

# ─── Traceroute al abrirse un corte e historial de IP pública ────────────────
TRACE_MAX = 3000                  # characters kept per traceroute

# Destino del traceroute: el primer destino configurado que sea una IP; si todos son nombres, el primero que se resuelva.
# Nunca se pasa texto del usuario al comando: solo una dirección ya validada por ipaddress.
# EN: Traceroute destination: the first configured target that is an IP; if all are names, the first that resolves.
#     No user text is ever passed to the command: only an address already validated by ipaddress.
def trace_dest(cfg):
    names = []
    for t in cfg.get("targets", []):
        h = str(t.get("host") or "")
        try: return str(ipaddress.ip_address(h))
        except ValueError: names.append(h)
    for h in names:
        try: return str(ipaddress.ip_address(socket.gethostbyname(h)))
        except (OSError, ValueError): continue
    return None

# Ejecuta traceroute (si está instalado) y guarda el resultado asociado al corte. Con internet caído muestra hasta qué salto llega.
# EN: Run traceroute (if installed) and store the result tied to the outage. With the internet down it shows how far it gets.
def run_trace(start, cfg):
    exe = shutil.which("traceroute")
    dest = trace_dest(cfg) if exe else None
    if not dest: return
    try:
        p = subprocess.run([exe, "-n", "-w", "1", "-q", "1", "-m", "15", dest], capture_output=True, text=True, timeout=45, check=False)
        text = re.sub(r"[^\x20-\x7e\n]", " ", p.stdout or "")[:TRACE_MAX].strip()
    except (OSError, subprocess.SubprocessError) as e:
        log.warning(f"traceroute failed: {e}"); return
    if text:
        try: _db("INSERT OR REPLACE INTO wan_traces (start,dest,text) VALUES (?,?,?)", (start, dest, text))
        except Exception as e: log.warning(f"could not store the traceroute: {e}")  # noqa: BLE001 - se registra y el servicio sigue / logged, the service keeps running

def get_trace(start):
    try:
        rows = _db("SELECT dest,text FROM wan_traces WHERE start = ?", (int(start),), fetch=True)
        return {"dest": rows[0][0], "text": rows[0][1]} if rows else None
    except (sqlite3.Error, OSError, ValueError, TypeError): return None

# Recupera del registro de eventos los cambios de IP pública anteriores a la tabla de historial (el Resumen los guardaba como «wan_ipc»;
# el registro conserva solo los últimos 30 días / 300 eventos). No duplica los que ya están (±5 s).
# EN: Recover from the event log the public IP changes made before the history table existed (the Overview kept them as "wan_ipc";
#     the log keeps only the last 30 days / 300 events). Does not duplicate the ones already there (±5 s).
def backfill_ips():
    try:
        evs = auth.read_events(["wan"], 300)
        have = [r[0] for r in _db("SELECT ts FROM wan_ips", fetch=True)]
    except Exception as e:  # noqa: BLE001 - se registra y el servicio sigue / logged, the service keeps running
        log.warning(f"could not read the events: {e}"); return 0
    added = 0
    for e in evs:
        p = e.get("p") if isinstance(e, dict) else None
        if not isinstance(p, dict) or e.get("k") != "wan_ipc" or not isinstance(e.get("t"), int): continue
        try: ip = str(ipaddress.ip_address(str(p.get("ip")))); prev = str(ipaddress.ip_address(str(p["prev"]))) if p.get("prev") else None
        except ValueError: continue
        if any(abs(t - e["t"]) <= 5 for t in have): continue
        try: _db("INSERT OR REPLACE INTO wan_ips (ts,ip,prev) VALUES (?,?,?)", (e["t"], ip, prev)); have.append(e["t"]); added += 1
        except Exception as ex: log.warning(f"could not store the IP change: {ex}")  # noqa: BLE001 - se registra y el servicio sigue / logged, the service keeps running
    if added: log.info(f"public IP history: {added} earlier change(s) recovered from the events")
    return added

# Fecha de inicio del registro más antiguo (el primero que se conoció). Si es el de la IP actual, también es «desde cuándo» tiene esa IP.
# EN: Start date of the oldest record (the first one ever known). If it is the current IP's, it is also "since when" it has that IP.
def set_ip_since(ts):
    if not isinstance(ts, int) or isinstance(ts, bool) or not 946684800 <= ts <= int(time.time()):
        raise ValueError("Invalid date")
    rows = _db("SELECT ts,ip FROM wan_ips ORDER BY ts", fetch=True)
    if not rows: raise ValueError("No IP recorded yet")
    if len(rows) > 1 and ts >= rows[1][0]: raise ValueError("The date must be before the next change")
    _db("UPDATE wan_ips SET ts=? WHERE ts=?", (ts, rows[0][0]))
    if len(rows) == 1:                                          # the only record is the current IP: state keeps the same date
        with S.lock:
            S.ip_changed = ts
            try: auth.write_json(STATE_FILE, {"ip": S.ip, "changed": ts, "prev": S.ip_prev})
            except Exception as e: log.warning(f"could not store the state: {e}")  # noqa: BLE001 - se registra y el servicio sigue / logged, the service keeps running

# Si state.json trae una fecha para la IP actual distinta de la de su fila (editada a mano), manda state.json.
# EN: If state.json holds a date for the current IP that differs from its row (edited by hand), state.json wins.
def reconcile_ip_since():
    if not S.ip or not isinstance(S.ip_changed, int): return
    rows = _db("SELECT ts,ip FROM wan_ips ORDER BY ts DESC LIMIT 2", fetch=True)
    if not rows or rows[0][1] != S.ip or abs(rows[0][0] - S.ip_changed) <= 5: return
    if len(rows) > 1 and S.ip_changed <= rows[1][0]: return
    _db("UPDATE wan_ips SET ts=? WHERE ts=?", (S.ip_changed, rows[0][0]))

def recent_ips(limit=20):
    try:
        rows = _db("SELECT ts,ip,prev FROM wan_ips ORDER BY ts DESC LIMIT ?", (limit,), fetch=True)
        return [{"ts": a, "ip": b, "prev": c} for a, b, c in rows]
    except (sqlite3.Error, OSError): return []

def load_history() -> int:
    try:
        _db("DELETE FROM wan_samples WHERE ts < ?", (int(time.time()) - HIST_KEEP,))
        _db("DELETE FROM wan_speed WHERE ts < ?", (int(time.time()) - HIST_KEEP,))
        _db("DELETE FROM wan_targets WHERE ts < ?", (int(time.time()) - HIST_KEEP,))
        _db("DELETE FROM wan_outages WHERE start < ?", (int(time.time()) - HIST_KEEP,))
        _db("DELETE FROM wan_traces WHERE start < ?", (int(time.time()) - HIST_KEEP,))
        # wan_ips is never pruned: one row per IP change (a few bytes), so the whole history is kept / el historial de IP no se poda nunca
        rows = _db("SELECT ts,up,rtt,loss,jitter,gw,dns FROM wan_samples WHERE ts >= ? ORDER BY ts", (int(time.time()) - 43200,), fetch=True)
        with S.lock:
            for ts, up, rtt, loss, jit, gw, dns in rows: S.history.append({"ts": ts, "up": up, "rtt": rtt, "loss": loss, "jitter": jit, "gw": gw, "dns": dns})
        open_ = _db("SELECT start,scope FROM wan_outages WHERE end IS NULL ORDER BY start DESC LIMIT 1", fetch=True)
        if open_: S.down_since, S.scope, S.fails = open_[0][0], open_[0][1], DOWN_AFTER      # an outage was open when the service stopped: keep it open
        last = _db("SELECT ts FROM wan_speed ORDER BY ts DESC LIMIT 1", fetch=True)
        if last: S.speed_last = last[0][0]
        try: S.speed_low = wst.speed_stats(_db("SELECT ts,down,up,error FROM wan_speed WHERE ts >= ? ORDER BY ts", (int(time.time()) - 30 * 86400,), fetch=True),
                                          load_config()["speed"].get("plan_down"), load_config()["speed"].get("plan_up"), int(time.time()), lambda t: time.localtime(t).tm_hour)["low_streak"]
        except Exception: S.speed_low = 0  # noqa: BLE001 - red o servicio externo: cualquier fallo es «sin respuesta» / network or external service: any failure means «no answer»
        st = auth.read_json(STATE_FILE, {}, dict)
        if isinstance(st.get("ip"), str): S.ip, S.ip_changed = st["ip"], st.get("changed")
        if isinstance(st.get("prev"), str): S.ip_prev = st["prev"][:64]
        if S.ip and not _db("SELECT 1 FROM wan_ips LIMIT 1", fetch=True):        # first start with the history: seed it with the IP already known
            _db("INSERT OR REPLACE INTO wan_ips (ts,ip,prev) VALUES (?,?,?)", (S.ip_changed or int(time.time()), S.ip, S.ip_prev))
        backfill_ips()
        reconcile_ip_since()
        return len(rows)
    except Exception as e:  # noqa: BLE001 - se registra y el servicio sigue / logged, the service keeps running
        log.warning(f"could not load the history: {e}"); return 0

_sus = wst.Sustain(3)
LOSS_WARN, LAT_WARN = 5.0, 150.0

# Pérdida o latencia sostenidas (3 rondas seguidas) generan un evento al empezar y otro al terminar; un pico suelto no.
# EN: Sustained loss or latency (3 rounds in a row) create an event when they start and another when they end; a single spike does not.
def sustained_events(r):
    if not r["up"]: return                      # an outage has its own events
    for key, bad, ev, val in (("loss", r["loss"] is not None and r["loss"] >= LOSS_WARN, "wan_loss", r["loss"]),
                              ("lat", r["rtt"] is not None and r["rtt"] >= LAT_WARN, "wan_lat", r["rtt"])):
        ch = _sus.update(key, bad)
        if ch == "on": auth.record_event("wan", "warn", f"{'Packet loss' if key == 'loss' else 'High latency'} sustained ({round(val, 1)}{'%' if key == 'loss' else ' ms'})", ev, v=round(val, 1))
        elif ch == "off": auth.record_event("wan", "info", f"{'Packet loss' if key == 'loss' else 'Latency'} back to normal", ev + "_ok")

def speed_events(cfg):
    st = wst.speed_stats(_db("SELECT ts,down,up,error FROM wan_speed WHERE ts >= ? ORDER BY ts", (int(time.time()) - 30 * 86400,), fetch=True),
                         cfg["speed"].get("plan_down"), cfg["speed"].get("plan_up"), int(time.time()), lambda t: time.localtime(t).tm_hour)
    prev, S.speed_low = S.speed_low, st["low_streak"]
    _stats_cache[1] = None
    if prev is None: return
    last = st["last"] or {}
    if S.speed_low >= wst.LOW_STREAK and prev < wst.LOW_STREAK:
        auth.record_event("wan", "warn", f"Speed below 70 % of the plan in {S.speed_low} tests in a row", "wan_speed_low", n=S.speed_low, d=last.get("down") or 0, u=last.get("up") or 0)
    elif S.speed_low == 0 and prev >= wst.LOW_STREAK:
        auth.record_event("wan", "info", "Speed is back above 70 % of the plan", "wan_speed_ok")

# Registra el paso de «arriba» a «caído» (tras DOWN_AFTER rondas fallidas) y la recuperación; escribe eventos para la línea de tiempo del Resumen.
# EN: Record the change from "up" to "down" (after DOWN_AFTER failed rounds) and the recovery; writes events for the Overview timeline.
def track_outage(r, first_fail_ts):
    gw_ok = (r["gateway"] or {}).get("ok", True) if r.get("gateway") else True
    with S.lock:
        if r["up"]:
            S.fails = 0
            if S.down_since is not None:
                dur = r["ts"] - S.down_since
                S.down_since, S.scope = None, None
                try: _db("UPDATE wan_outages SET end = ? WHERE end IS NULL", (r["ts"],))
                except Exception as e: log.warning(f"could not close the outage: {e}")  # noqa: BLE001 - se registra y el servicio sigue / logged, the service keeps running
                auth.record_event("wan", "info", f"Internet connection restored after {int(dur)} s", "wan_up", d=int(dur))
                log.info(f"connection restored after {int(dur)} s")
            return
        S.fails += 1
        if S.fails >= DOWN_AFTER and S.down_since is None:
            S.down_since, S.scope = first_fail_ts, rtr.classify_scope(gw_ok, _router_fresh())
            try: _db("INSERT OR REPLACE INTO wan_outages (start,end,scope) VALUES (?,NULL,?)", (S.down_since, S.scope))
            except Exception as e: log.warning(f"could not store the outage: {e}")  # noqa: BLE001 - se registra y el servicio sigue / logged, the service keeps running
            auth.record_event("wan", "crit", "Internet connection down" + (" (local network too)" if S.scope == "lan" else ""), "wan_down_" + S.scope)
            threading.Thread(target=run_trace, args=(S.down_since, load_config()), daemon=True, name="wan-trace").start()
            log.warning(f"connection down ({S.scope})")

# La última lectura del router, solo si es reciente (si el router dejó de responder, su dato viejo no sirve para diagnosticar).
# EN: The latest router reading, only if recent (if the router stopped answering, its old data is no good for diagnosis).
def _router_fresh(max_age=120):
    r = S.router
    return r if r and time.time() - r.get("ts", 0) <= max_age else None

def compute_alerts(s: dict) -> list:
    a = []
    if s.get("down_since"): a.append({"lv": "crit", "type": "down_" + (s.get("scope") or "internet"), "value": s["down_since"]})
    else:
        if s.get("loss") is not None and s["loss"] >= 5: a.append({"lv": "warn", "type": "loss", "value": s["loss"]})
        if s.get("rtt") is not None and s["rtt"] >= 150: a.append({"lv": "warn", "type": "latency", "value": s["rtt"]})
        if s.get("dns") is not None and s["dns"] >= 500: a.append({"lv": "warn", "type": "dns_slow", "value": s["dns"]})
        elif s.get("dns_fail"): a.append({"lv": "warn", "type": "dns_fail"})
    if (S.speed_low or 0) >= wst.LOW_STREAK: a.append({"lv": "warn", "type": "speed_low", "value": S.speed_low})
    if s.get("ip_changed") and time.time() - s["ip_changed"] < IP_NOTICE_S: a.append({"lv": "info", "type": "ip_changed", "value": s.get("public_ip"), "prev": s.get("ip_prev")})
    return a

# La lectura que ve la página: última ronda, estado, IP, alertas.
# EN: The reading the page sees: last round, state, IP, alerts.
def snapshot(cfg):
    with S.lock:
        r = S.last
        if not r: return None
        s = {"ts": r["ts"], "up": r["up"], "rtt": r["rtt"], "jitter": r["jitter"], "loss": r["loss"], "gw": r["gw"], "dns": r["dns"],
             "dns_fail": bool(cfg["dns_name"]) and r["dns"] is None, "targets": r["targets"], "gateway": r["gateway"], "gateway_ip": S.gw,
             "down_since": S.down_since, "scope": S.scope, "public_ip": S.ip, "ip_changed": S.ip_changed, "ip_prev": S.ip_prev, "router": S.router}
    s["alerts"] = compute_alerts(s)
    s["router_check"] = router_crosscheck(s.get("router"))
    return s

# Compara lo que dice el router («conectado hace X») con los cortes que registró este monitor en ese mismo período.
# EN: Compares what the router says ("connected for X") with the outages this monitor recorded in that same period.
def router_crosscheck(r):
    try:
        up = r.get("uptime") if isinstance(r, dict) and r.get("ok") and r.get("wan_up") else None
        if not isinstance(up, int) or up <= 0: return None
        since = int(time.time()) - up
        n, wan = _db("SELECT COUNT(*), COALESCE(SUM(scope = 'wan'), 0) FROM wan_outages WHERE COALESCE(end, ?) >= ?", (int(time.time()), since), fetch=True)[0]
        return {"since": since, "uptime": up, "outages": int(n), "wan_outages": int(wan)}
    except (sqlite3.Error, OSError, ValueError, TypeError): return None

# ─── Hilos ────────────────────────────────────────────────────────────────────
_stop = threading.Event()

def probe_loop():
    first_fail = None
    while not _stop.is_set():
        cfg = load_config()
        if S.speed_running: S.wake.wait(2); S.wake.clear(); continue          # the line is saturated on purpose: do not judge it
        gw_ip = (default_gateway() if cfg["gateway"] == "auto" else cfg["gateway"]) or None
        S.gw = gw_ip
        t0 = time.time()
        try: r = probe_round(cfg, gw_ip)
        except Exception as e:  # noqa: BLE001 - se registra y el servicio sigue / logged, the service keeps running
            log.error(f"probe round failed: {e}"); S.wake.wait(5); continue
        if not r["up"] and first_fail is None: first_fail = r["ts"]
        if r["up"]: first_fail = None
        with S.lock: S.last = r; S.history.append({"ts": r["ts"], "up": 1 if r["up"] else 0, "rtt": r["rtt"], "loss": r["loss"], "jitter": r["jitter"], "gw": r["gw"], "dns": r["dns"]})
        store_sample(r)
        store_targets(r)
        track_outage(r, first_fail or r["ts"])
        try: sustained_events(r)
        except Exception as e: log.warning(f"sustained events: {e}")  # noqa: BLE001 - se registra y el servicio sigue / logged, the service keeps running
        if r["up"] and cfg["ip_url"] and time.time() - S.ip_checked >= IP_EVERY: check_ip(cfg)
        S.wake.wait(max(1.0, cfg["interval"] - (time.time() - t0))); S.wake.clear()

# Hilo del router: lee el estado WAN que informa el router. Mientras hay fallos de internet pregunta cada 10 s para poder diagnosticar el corte.
# EN: Router thread: reads the WAN state the router reports. While internet probes are failing it asks every 10 s so the outage can be diagnosed.
def router_round(cfg):
    rc = cfg["router"]
    host = rc["host"] or S.gw or default_gateway() or ""
    res = rtr.check(rc, host, learn=learn_router_pin)
    with S.lock:
        S.router = res
        gw = (S.last or {}).get("gateway")
        gw_ok = gw.get("ok", True) if gw else True
        down = S.down_since is not None
    if res["ok"]:
        ch = auth.state_changed("wan-router", bool(res["wan_up"]))
        if ch: auth.record_event("wan", "warn" if not res["wan_up"] else "info", "Router reports its WAN link " + ("up" if res["wan_up"] else "down"), "wan_rt_up" if res["wan_up"] else "wan_rt_down")
    if down:                                                     # an outage is open: the router may now tell where it is
        with S.lock:
            new = rtr.classify_scope(gw_ok, res)
            if new == "wan" and S.scope == "internet":
                S.scope = "wan"
                try: _db("UPDATE wan_outages SET scope = ? WHERE end IS NULL", ("wan",))
                except Exception as e: log.warning(f"could not update the outage: {e}")  # noqa: BLE001 - se registra y el servicio sigue / logged, the service keeps running
                auth.record_event("wan", "crit", "Internet down: the router reports its WAN link is down", "wan_down_wan")
    return res

def router_loop():
    while not _stop.is_set():
        cfg = load_config()
        if not cfg["router"]["enabled"]:
            S.router = None; S.router_wake.wait(10); S.router_wake.clear(); continue
        try: router_round(cfg)
        except Exception as e: log.error(f"router check failed: {e}")  # noqa: BLE001 - se registra y el servicio sigue / logged, the service keeps running
        S.router_wake.wait(10 if S.fails > 0 else cfg["router"]["every"]); S.router_wake.clear()

IP_NOTICE_S = 24 * 3600          # the "public IP changed" notice stays visible for a day

def check_ip(cfg):
    S.ip_checked = time.time()
    ip = fetch_public_ip(cfg["ip_url"])
    if not ip: return
    with S.lock:
        old = S.ip
        if ip != old:
            S.ip, S.ip_changed = ip, (int(time.time()) if old else S.ip_changed)
            if old: S.ip_prev = old
            try: auth.write_json(STATE_FILE, {"ip": ip, "changed": S.ip_changed, "prev": S.ip_prev})
            except Exception as e: log.warning(f"could not store the state: {e}")  # noqa: BLE001 - se registra y el servicio sigue / logged, the service keeps running
            try: _db("INSERT OR REPLACE INTO wan_ips (ts,ip,prev) VALUES (?,?,?)", (int(time.time()), ip, old))
            except Exception as e: log.warning(f"could not store the IP change: {e}")  # noqa: BLE001 - se registra y el servicio sigue / logged, the service keeps running
            if old: auth.record_event("wan", "warn", f"Public IP changed from {old} to {ip}", "wan_ipc", ip=ip, prev=old)

def start_speedtest():
    cfg = load_config()
    with S.lock:
        if S.speed_running: return False
        S.speed_running, S.speed_started = True, time.time()
    def work():
        try:
            res = run_speedtest(cfg)
            _db("INSERT OR REPLACE INTO wan_speed (ts,down,up,ping,server,error) VALUES (?,?,?,?,?,?)", (res["ts"], res["down"], res["up"], res["ping"], res["server"], res["error"]))
            S.speed_last = res["ts"]
            try: speed_events(cfg)
            except Exception as e: log.warning(f"speed events: {e}")  # noqa: BLE001 - se registra y el servicio sigue / logged, the service keeps running
            log.info(f"speed test: ↓ {res['down']} Mb/s ↑ {res['up']} Mb/s ping {res['ping']} ms" + (f" [{res['error']}]" if res["error"] else ""))
        except Exception as e: log.error(f"speed test failed: {e}")  # noqa: BLE001 - se registra y el servicio sigue / logged, the service keeps running
        finally:
            with S.lock: S.speed_running = False
            S.wake.set()
    threading.Thread(target=work, daemon=True, name="speedtest").start()
    return True

def next_speedtest(cfg):
    sp = cfg["speed"]
    if not sp["enabled"] or not sp["every_minutes"]: return None
    return (S.speed_last + sp["every_minutes"] * 60) if S.speed_last else (_STARTED + 300)       # first test 5 min after the first start

def speed_scheduler():
    while not _stop.is_set():
        _stop.wait(60)
        try:
            cfg = load_config(); nxt = next_speedtest(cfg)
            if nxt and time.time() >= nxt and S.last and S.last["up"] and not S.speed_running: start_speedtest()
        except Exception as e: log.error(f"scheduler: {e}")  # noqa: BLE001 - se registra y el servicio sigue / logged, the service keeps running

def _pruner():
    while True:
        time.sleep(3600)
        try:
            cut = int(time.time()) - HIST_KEEP
            _db("DELETE FROM wan_samples WHERE ts < ?", (cut,)); _db("DELETE FROM wan_speed WHERE ts < ?", (cut,)); _db("DELETE FROM wan_targets WHERE ts < ?", (cut,)); _db("DELETE FROM wan_outages WHERE start < ? AND end IS NOT NULL", (cut,)); _db("DELETE FROM wan_traces WHERE start < ?", (cut,))
        except Exception as e: log.warning(f"could not prune: {e}")  # noqa: BLE001 - se registra y el servicio sigue / logged, the service keeps running

# ─── Health ───────────────────────────────────────────────────────────────────
def health_report(detailed=False):
    c = auth.check_common()
    c["wan_file"] = auth.check_file(DATA_FILE)
    c["ping_tool"] = auth.chk(auth.OK, "ping found") if shutil.which("ping") else auth.chk(auth.WARN, "ping not installed (apt install iputils-ping): TCP targets still work")
    with S.lock: last = S.last
    if last is None: c["probe"] = auth.chk(auth.OK, "starting")
    else:
        age = time.time() - last["ts"]
        c["probe"] = auth.chk(auth.WARN, f"last probe {int(age)} s ago") if age > max(120, 4 * load_config()["interval"]) else auth.chk(auth.OK, f"last probe {int(age)} s ago")
    rc = load_config()["router"]
    if rc["enabled"]:
        r = S.router
        if r is None: c["router"] = auth.chk(auth.OK, "router check starting")
        elif r.get("ok"): c["router"] = auth.chk(auth.OK, "router answers: WAN " + ("up" if r.get("wan_up") else "down"))
        else: c["router"] = auth.chk(auth.WARN, "router check failed: " + str(r.get("error"))[:100])
    return auth.health_reply("wan", c, detailed)

# ─── HTTP ─────────────────────────────────────────────────────────────────────
class H(BaseHTTPRequestHandler):
    timeout = 30
    def log_message(self, fmt, *a):
        # send_error() llega aquí con (código, mensaje) y un 501 de HEAD trae el mensaje en a[1]: solo se registra un código numérico.
        # EN: send_error() arrives here with (code, message) and a HEAD 501 carries the message in a[1]: only a numeric code is logged.
        c = str(a[1]) if len(a) > 1 else ""
        if c.isdigit() and int(c) >= 400: log.warning(f"{self.client_address[0]} {c}")
    def _json(self, code, payload):
        body = json.dumps(payload).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers(); self.wfile.write(body)
    def _body(self):
        try:
            n = int(self.headers.get("Content-Length", 0))
            if n < 0 or n > 8192: return None
            d = json.loads(self.rfile.read(n)) if n else {}
            return d if isinstance(d, dict) else None      # EN: a list/number would crash the handlers (500); reject it (400)
        except (ValueError, TypeError, OSError, RecursionError): return None
    def _tok(self):
        return auth.token_from_request(dict(self.headers), self.headers.get("Cookie", ""))
    def _file(self, path, mime):
        try:
            c = Path(path).read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", mime); self.send_header("Content-Length", str(len(c)))
            self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0"); self.send_header("Pragma", "no-cache")
            self.end_headers(); self.wfile.write(c)
        except FileNotFoundError: self._json(404, {"error": "Not found"})

    # GET: página, versión y salud son públicos; el resto exige sesión con WAN «readonly». Rutas: /api/wan, /api/wan/history, /api/me.
    # EN: GET: page, version and health are public; the rest requires a session with WAN "readonly".
    def do_GET(self):
        path = urlparse(self.path).path.rstrip("/") or "/"
        tok  = self._tok()
        if auth.serve_asset(self, STATIC_DIR, path): return
        if path in ("/", "/index.html"):
            return self._file(STATIC_DIR / "index.html", "text/html; charset=utf-8")
        if path == "/api/version":
            return self._json(200, {"version": auth.version()} if (auth.get_session(tok) or auth.is_local_request(self)) else {})
        if path == "/api/health":
            code, body = health_report(auth.health_mode(self, tok))
            return self._json(code, body)
        if path == "/api/me":
            sess = auth.get_session(tok)
            return self._json(200, {"username": sess["username"], "permissions": sess["permissions"],
                      "disabled": auth.disabled_modules()} if sess else {})
        if not auth.check_permission(tok, "wan", "readonly"):
            return self._json(401, {"error": "Unauthorized"})
        if path == "/api/wan":
            cfg = load_config()
            with_hist = parse_qs(urlparse(self.path).query).get("hist", ["1"])[0] != "0"
            with S.lock: hist = list(S.history) if with_hist else []
            return self._json(200, {"config": public_config(cfg), "snap": snapshot(cfg), "history": hist, "uptime": uptime(), "outages": recent_outages(), "ips": recent_ips(), "speed": recent_speed(), "stats": wan_stats(cfg),
                                    "speed_running": S.speed_running, "next_speed": next_speedtest(cfg), "ping_available": bool(shutil.which("ping")), "engines": engines_available()})
        if path == "/api/wan/trace":
            try: tr = get_trace(int(parse_qs(urlparse(self.path).query).get("start", [""])[0]))
            except ValueError: return self._json(400, {"error": "Invalid outage"})
            return self._json(200, {"trace": tr}) if tr else self._json(404, {"error": "No traceroute for this outage"})
        if path == "/api/wan/history":
            rng = parse_qs(urlparse(self.path).query).get("range", ["1d"])[0]
            if rng not in RANGE_SECS and rng != "all": return self._json(400, {"error": "Invalid range"})
            prev = parse_qs(urlparse(self.path).query).get("prev", ["0"])[0] == "1"
            kind = parse_qs(urlparse(self.path).query).get("kind", [""])[0]
            try: return self._json(200, {"range": rng, "prev": prev, "history": speed_range(rng, prev) if kind == "speed" else history_range(rng, prev)})
            except Exception as e:  # noqa: BLE001 - error de la petición: se responde sin caer / request error: answered without crashing
                log.warning(f"history query failed: {e}"); return self._json(500, {"error": "Could not read the history"})
        self._json(404, {"error": "Not found"})

    # POST: login/logout; «execute»: medir la velocidad ahora; solo admin: cambiar la configuración.
    # EN: POST: login/logout; "execute": measure the speed now; admin only: change the configuration.
    def do_POST(self):
        if auth.cross_origin(self.headers): return self._json(403, {"error": "Cross-origin request blocked"})
        path = urlparse(self.path).path.rstrip("/")
        tok  = self._tok()
        body = self._body()
        if body is None: return self._json(400, {"error": "Invalid request body"})
        if path == "/api/login":
            r, err = auth.login_session(self, body.get("username", ""), body.get("password", ""), body.get("remember"), body.get("code"))   # the service checks the password and opens the session
            if not r: return self._json(err[0], {"error": err[1]})
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Set-Cookie", auth.session_cookie(r["token"], r["ttl"]))
            br = json.dumps({"ok": True, "username": r["username"], "permissions": r["permissions"], "must_change_password": r["must_change_password"]}).encode()
            self.send_header("Content-Length", str(len(br)))
            self.end_headers(); self.wfile.write(br); return
        if path == "/api/logout":
            auth.delete_session(tok); return self._json(200, {"ok": True})
        if path == "/api/wan/speedtest":
            if not auth.check_permission(tok, "wan", "execute"):
                return self._json(403 if auth.check_permission(tok, "wan", "readonly") else 401, {"error": "Execute permission required"})
            if time.time() - S.speed_started < 30: return self._json(429, {"error": "A speed test ran a moment ago"})
            if not start_speedtest(): return self._json(409, {"error": "A speed test is already running"})
            who = (auth.get_session(tok) or {}).get("username", "?"); log.info(f"{who}: speed test started")
            return self._json(202, {"ok": True})
        if path == "/api/wan/config":
            if not auth.check_permission(tok, "wan", "admin"):
                return self._json(403 if auth.check_permission(tok, "wan", "readonly") else 401, {"error": "Admin permission required"})
            with _cfg_lock:
                try: cfg = validate(body, load_config())
                except ValueError as e: return self._json(400, {"error": str(e)})
                save_config(cfg)
            S.ip_checked = 0; S.wake.set(); S.router_wake.set()
            who = (auth.get_session(tok) or {}).get("username", "?")
            auth.audit(who, "wan_config_changed", "wan-monitor", "router " + ("on" if cfg["router"]["enabled"] else "off") + " " + cfg["router"]["type"], auth.client_ip(self), module="wan")
            return self._json(200, {"config": public_config(cfg)})
        if path == "/api/wan/ip/since":
            if not auth.check_permission(tok, "wan", "admin"):
                return self._json(403 if auth.check_permission(tok, "wan", "readonly") else 401, {"error": "Admin permission required"})
            try: set_ip_since(body.get("ts"))
            except ValueError as e: return self._json(400, {"error": str(e)})
            who = (auth.get_session(tok) or {}).get("username", "?")
            auth.audit(who, "wan_ip_since_changed", "wan-monitor", str(body.get("ts")), auth.client_ip(self), module="wan")
            return self._json(200, {"ips": recent_ips()})
        if path == "/api/wan/router/test":
            if not auth.check_permission(tok, "wan", "admin"):
                return self._json(403 if auth.check_permission(tok, "wan", "readonly") else 401, {"error": "Admin permission required"})
            if time.time() - S.router_test < 3: return self._json(429, {"error": "Wait a few seconds between tests"})
            S.router_test = time.time()
            try: cfg = validate({"router": {**(body.get("router") if isinstance(body.get("router"), dict) else {}), "enabled": False}}, load_config())
            except ValueError as e: return self._json(400, {"error": str(e)})
            rc = cfg["router"]
            if not rc["password"]: return self._json(400, {"error": "Type the router password first"})
            pin = load_config()["router"].get("tls_pin")
            if pin: rc["tls_pin"] = pin                                    # the test is checked against the stored fingerprint, never learns
            host = rc["host"] or S.gw or default_gateway() or ""
            res = rtr.check(rc, host)
            return self._json(200, {"result": {k: res.get(k) for k in ("ok", "wan_up", "ip", "uptime", "detail", "error", "type", "host")}})
        self._json(404, {"error": "Not found"})

# Arranque: permiso «wan» para usuarios antiguos (una vez), hilos y servidor en loopback.
# EN: Startup: "wan" permission for old users (once), threads and the loopback server.
if __name__ == "__main__":
    auth.prepare_module(DATA_DIR, Path(__file__).parent, LEGACY_FILES)
    STATIC_DIR.mkdir(parents=True, exist_ok=True)
    try:
        if auth.ensure_permissions(("wan",)): log.info("'wan' permissions updated")
    except Exception as e:  # noqa: BLE001 - se registra y el servicio sigue / logged, the service keeps running
        log.warning(f"Permissions: {e}")
    log.info(f"WAN Monitor en http://{HOST}:{PORT}")
    n = load_history()
    if n: log.info(f"History restored: {n} samples")
    for fn, name in ((probe_loop, "probe"), (router_loop, "router"), (speed_scheduler, "speed-scheduler"), (_pruner, "pruner")):
        threading.Thread(target=fn, daemon=True, name=name).start()
    try:
        srv = ThreadingHTTPServer((HOST, PORT), H)
        srv.daemon_threads = True
        srv.serve_forever()
    except KeyboardInterrupt: sys.exit(0)
