"""Router checks for WAN Monitor: ask the router whether ITS internet link (WAN) is up, to tell a line/provider outage from a local one.
ES: Cada adaptador habla con un tipo de router y devuelve lo mismo: {ok, wan_up, ip, uptime, sys_uptime, error}. `wan_up` es True/False según lo que informa el router, o None si no se
    pudo saber. Solo lee: nunca cambia nada en el router. Solo biblioteca estándar.
EN: Each adapter talks to one router type and returns the same thing: {ok, wan_up, ip, uptime, sys_uptime, error}. `wan_up` is True/False as the router reports it, or None when it
    could not be told. Read only: it never changes anything on the router. Standard library only."""
import base64
import hashlib
import hmac
import http.client
import http.cookiejar
import json
import os
import re
import ssl
import time
import urllib.error
import urllib.request

TYPES = ("huawei", "openwrt", "ddwrt", "tplink")
TIMEOUT = 6
MAX_BODY = 512 * 1024

class RouterError(Exception):
    pass

class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k): return None

# Huella fijada (TOFU, como NAS, DNS, Net y Proxmox): los routers usan certificados autofirmados, así que no se validan contra las CA;
# en su lugar la primera conexión fija la huella SHA-256 y, si luego cambia, se corta ANTES de enviar usuario o contraseña.
# EN: Pinned fingerprint (TOFU, like NAS, DNS, Net and Proxmox): routers use self-signed certificates, so they are not validated against
#     the CAs; instead the first connection pins the SHA-256 fingerprint and, if it later changes, the connection is dropped BEFORE the
#     user or password is sent.
class PinError(Exception):
    pass

def _pinned_handler(ctx, pin, learn):
    class Conn(http.client.HTTPSConnection):
        def connect(self):
            super().connect()
            fp = hashlib.sha256(self.sock.getpeercert(True) or b"").hexdigest()
            if pin and not hmac.compare_digest(pin, fp):
                self.close()
                raise PinError("the router's certificate changed (pinned fingerprint mismatch); nothing was sent. "
                               "Save the router settings to learn it again")
            if not pin and learn: learn(fp)
    class Handler(urllib.request.HTTPSHandler):
        def https_open(self, req): return self.do_open(Conn, req, context=ctx)
    return Handler(context=ctx)

class Http:
    """One small HTTP session (cookies kept) against one router. Never follows redirects to other hosts.
    Over HTTPS the certificate is pinned: `pin` is the stored fingerprint (None = learn it, `learn(fp)` keeps it)."""
    def __init__(self, base, basic=None, pin=None, learn=None):
        self.base, self.basic = base.rstrip("/"), basic
        ctx = ssl.create_default_context()
        ctx.check_hostname, ctx.verify_mode = False, ssl.CERT_NONE         # nosec B501 - pinned fingerprint instead / huella fijada en su lugar
        self.jar = http.cookiejar.CookieJar(http.cookiejar.DefaultCookiePolicy(allowed_domains=None))
        self.opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self.jar), _pinned_handler(ctx, pin, learn), _NoRedirect())
    def request(self, path, data=None, headers=None, method=None):
        h = dict(headers or {})
        if self.basic: h["Authorization"] = "Basic " + base64.b64encode(f"{self.basic[0]}:{self.basic[1]}".encode()).decode()
        body = data.encode() if isinstance(data, str) else data
        req = urllib.request.Request(self.base + path, data=body, headers=h, method=method or ("POST" if body is not None else "GET"))
        try:
            with self.opener.open(req, timeout=TIMEOUT) as r: return r.status, r.read(MAX_BODY).decode("utf-8", "replace")
        except urllib.error.HTTPError as e:
            try: txt = e.read(MAX_BODY).decode("utf-8", "replace")
            except Exception: txt = ""  # noqa: BLE001 - red o servicio externo: cualquier fallo es «sin respuesta» / network or external service: any failure means «no answer»
            return e.code, txt
        except PinError as e:
            raise RouterError(str(e))
        except urllib.error.URLError as e:
            if isinstance(e.reason, PinError): raise RouterError(str(e.reason))
            raise RouterError("no connection to the router: " + str(e.reason)[:100])
        except (OSError, ssl.SSLError, http.client.HTTPException) as e:
            # HTTPException: respuesta cortada o mal formada (IncompleteRead, BadStatusLine). / EN: truncated or malformed answer.
            raise RouterError("no connection to the router: " + (str(e) or type(e).__name__)[:100])

def _json(txt, what):
    try: v = json.loads(txt)
    except ValueError: raise RouterError(f"{what}: the router did not answer with JSON")
    return v

# uptime = segundos con la WAN conectada; sys_uptime = segundos desde que el router encendió (None si el modelo no lo informa).
# EN: uptime = seconds the WAN has been connected; sys_uptime = seconds since the router booted (None when the model does not report it).
def _res(wan_up, ip=None, uptime=None, detail="", sys_uptime=None):
    return {"ok": wan_up is not None, "wan_up": wan_up, "ip": ip or None, "uptime": uptime, "sys_uptime": sys_uptime, "detail": detail[:160], "error": ""}

_MAX_SECS = 20 * 365 * 86400                                                      # más que esto es un dato roto / more than this is broken data
def _secs(v):
    """Segundos enteros entre 0 y 20 años, o None; nunca lanza (Infinity, NaN, texto). / EN: Whole seconds between 0 and 20 years, or None; never raises."""
    if isinstance(v, bool): return None
    if isinstance(v, str): v = int(v.strip()) if v.strip().isascii() and v.strip().isdigit() else None
    if not isinstance(v, (int, float)) or not 0 <= v <= _MAX_SECS: return None              # NaN también queda fuera / NaN is out too
    return int(v)

# ─── Huawei (HiLink: WiFi AX3, Mesh 3/7, WS7xxx …) ────────────────────────────────────────────────
# ES: Entrada tipo SCRAM-SHA256 (nonce → sal e iteraciones → prueba del cliente) y luego GET api/ntwk/wandetect. Protocolo documentado por el proyecto público
#     huawei_mesh_router. EN: SCRAM-SHA256-like login (nonce → salt and iterations → client proof), then GET api/ntwk/wandetect.
def huawei_proof(password, salt_hex, iterations, first_nonce, server_nonce):
    salted = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt_hex), iterations, 32)
    auth_msg = f"{first_nonce},{server_nonce},{server_nonce}"
    client_key = hmac.new(b"Client Key", salted, hashlib.sha256).digest()
    stored = hashlib.sha256(client_key).digest()
    sig = hmac.new(auth_msg.encode(), stored, hashlib.sha256).digest()
    return bytes(a ^ b for a, b in zip(client_key, sig)).hex()

def _hw_err(d, what):
    if isinstance(d, dict):
        for k in ("err", "errcode"):
            if d.get(k) not in (None, 0):
                cat = str(d.get("errorCategory") or "")
                if cat == "user_pass_err": raise RouterError("wrong user or password")
                if cat == "Too_Many_user": raise RouterError("the router has too many open sessions")
                raise RouterError(f"{what}: the router refused it ({k}={d.get(k)} {cat})".strip())

def check_huawei(c, http):
    st, html = http.request("/html/index.html")
    mp, mt = re.search(r'<meta name="csrf_param" content="([^"]+)"', html), re.search(r'<meta name="csrf_token" content="([^"]+)"', html)
    if st != 200 or not mp or not mt: raise RouterError("this does not look like a Huawei HiLink router (no login page found)")
    csrf = {"csrf_param": mp.group(1), "csrf_token": mt.group(1)}
    def post(path, data):
        nonlocal csrf
        s, t = http.request("/" + path, json.dumps({"csrf": csrf, "data": data}), {"Content-Type": "text/plain; charset=UTF-8"})
        if s != 200: raise RouterError(f"{path}: HTTP {s}")
        d = _json(t, path)
        if isinstance(d, dict) and "csrf_param" in d and "csrf_token" in d: csrf = {"csrf_param": d["csrf_param"], "csrf_token": d["csrf_token"]}
        _hw_err(d, path); return d
    first = os.urandom(32).hex()
    d = post("api/system/user_login_nonce", {"username": c["user"], "firstnonce": first})
    try: proof = huawei_proof(c["password"], d["salt"], int(d["iterations"]), first, d["servernonce"])
    except (KeyError, ValueError, TypeError): raise RouterError("unexpected login answer from the router")
    post("api/system/user_login_proof", {"clientproof": proof, "finalnonce": d["servernonce"]})
    try:
        s, t = http.request("/api/ntwk/wandetect")
        d = _json(t, "wandetect")
        if s != 200 or not isinstance(d, dict) or "Status" not in d: raise RouterError("the router did not report the WAN status (unexpected answer)")
        ip = d.get("ExternalIPAddress"); ip = None if ip in (None, "", "-", "0.0.0.0") else str(ip)  # nosec B104 - compares the router answer, does not bind
        return _res(str(d.get("Status")) == "Connected", ip, _secs(d.get("Uptime")), "Status=" + str(d.get("Status")), _huawei_sys_uptime(http))
    finally:
        try: post("api/system/user_logout", {})
        except Exception: pass  # noqa: BLE001, S110 - limpieza al terminar; un fallo no cambia el resultado / EN: cleanup; a failure does not change the result

def _huawei_sys_uptime(http):
    """Encendido del router (api/system/deviceinfo → UpTime); de esa respuesta no se guarda nada más. Si falla, None sin romper el chequeo.
    EN: Router uptime (api/system/deviceinfo → UpTime); nothing else from that answer is kept. On failure, None without breaking the check."""
    try:
        s, t = http.request("/api/system/deviceinfo")
        d = _json(t, "deviceinfo") if s == 200 else None
        return _secs(d.get("UpTime")) if isinstance(d, dict) else None
    except (RouterError, OSError, ValueError): return None

# ─── OpenWrt (ubus por HTTP / ubus over HTTP, uhttpd-mod-ubus) ───────────────────────────────────
def check_openwrt(c, http):
    n = [0]
    def call(sid, obj, method, args):
        n[0] += 1
        s, t = http.request("/ubus", json.dumps({"jsonrpc": "2.0", "id": n[0], "method": "call", "params": [sid, obj, method, args]}), {"Content-Type": "application/json"})
        if s != 200: raise RouterError(f"ubus: HTTP {s} (is uhttpd-mod-ubus installed?)")
        d = _json(t, "ubus")
        if isinstance(d, dict) and d.get("error"): raise RouterError("ubus: " + str((d["error"] or {}).get("message", "error"))[:80])
        r = d.get("result") if isinstance(d, dict) else None
        if not isinstance(r, list) or not r: raise RouterError("ubus: unexpected answer")
        if r[0] == 6: raise RouterError("wrong user or password" if obj == "session" else "this user may not read the network status (ubus access denied)")
        if r[0] != 0: raise RouterError(f"ubus {obj}.{method}: code {r[0]}")
        return r[1] if len(r) > 1 and isinstance(r[1], dict) else {}
    sid = call("0" * 32, "session", "login", {"username": c["user"], "password": c["password"]}).get("ubus_rpc_session")
    if not isinstance(sid, str): raise RouterError("wrong user or password")
    try:
        d = call(sid, "network.interface." + c["interface"], "status", {})
        addr = (d.get("ipv4-address") or [{}])[0].get("address") if isinstance(d.get("ipv4-address"), list) and d.get("ipv4-address") else None
        if "up" not in d: raise RouterError(f"interface '{c['interface']}' did not report its state")
        # system.info puede no estar en la ACL del usuario: sin él, el chequeo sigue igual. / EN: system.info may be outside the user's ACL: the check goes on.
        try: sys_up = _secs(call(sid, "system", "info", {}).get("uptime"))
        except RouterError: sys_up = None
        return _res(bool(d.get("up")), addr, _secs(d.get("uptime")), f"{c['interface']} proto={d.get('proto', '?')}", sys_up)
    finally:
        try: call(sid, "session", "destroy", {})
        except Exception: pass  # noqa: BLE001, S110 - limpieza al terminar; un fallo no cambia el resultado / EN: cleanup; a failure does not change the result

# ─── DD-WRT (páginas «live» con HTTP básico / "live" pages with HTTP basic) ──────────────────────
_RE_KV = re.compile(r"\{(\w+)::(.*?)\}", re.DOTALL)
_IP4 = re.compile(r"^\d{1,3}(?:\.\d{1,3}){3}$")

def parse_ddwrt(text):
    kv = {k: v.strip() for k, v in _RE_KV.findall(text)}
    st, ip = kv.get("wan_status") or kv.get("wan_state") or "", kv.get("wan_ipaddr", "")
    ip = ip if _IP4.match(ip) else ""
    if st:
        s = st.lower()
        up = ("connected" in s or "up" == s) and "disconnected" not in s and "not connected" not in s
    elif "wan_ipaddr" in kv: up = bool(ip) and ip != "0.0.0.0"  # nosec B104 - compares the router answer, does not bind
    else: return None, None, None, ""
    upt = re.match(r"\s*(?:(\d+) days?,\s*)?(\d+):(\d+):(\d+)", kv.get("wan_uptime", "") or "")
    secs = (int(upt.group(1) or 0) * 86400 + int(upt.group(2)) * 3600 + int(upt.group(3)) * 60 + int(upt.group(4))) if upt else None
    return up, (ip if ip not in ("", "0.0.0.0") else None), secs, "wan_status=" + st if st else "wan_ipaddr=" + kv.get("wan_ipaddr", "")  # nosec B104 - compares the router answer, does not bind

# Encendido según `uptime` de DD-WRT: «10:23:45 up 3 days,  4:05,  load average: …», «up 12 min», «up 1 day, 12 min», «up  4:05».
# EN: Uptime from DD-WRT's `uptime`: "10:23:45 up 3 days,  4:05,  load average: …", "up 12 min", "up 1 day, 12 min", "up  4:05".
_RE_UP = re.compile(r"\bup\s+(?:(\d+)\s+days?,\s*)?(?:(\d+):(\d{2})|(\d+)\s+min)")
def parse_ddwrt_sys_uptime(text):
    m = _RE_UP.search(dict(_RE_KV.findall(text)).get("uptime", "") or "")
    if not m: return None
    return int(m.group(1) or 0) * 86400 + (int(m.group(2)) * 3600 + int(m.group(3)) * 60 if m.group(2) else int(m.group(4)) * 60)

def check_ddwrt(c, http):
    last = ""
    for path in ("/Status_Router.live.asp", "/Status_Internet.live.asp"):
        s, t = http.request(path)
        if s == 401: raise RouterError("wrong user or password")
        if s != 200: last = f"HTTP {s} on {path}"; continue
        up, ip, secs, det = parse_ddwrt(t)
        if up is not None: return _res(up, ip, secs, det, parse_ddwrt_sys_uptime(t))
        last = f"{path} has no WAN state"
    raise RouterError("could not read the WAN state from DD-WRT (" + last + ")")

# ─── TP-Link (firmware con interfaz «userRpm», HTTP básico) / (firmware with the "userRpm" interface, HTTP basic) ─────────────
# ES: Los TP-Link nuevos (Archer/Deco con inicio cifrado) no se pueden leer sin cifrado propio: se avisa.
# EN: Newer TP-Link models (Archer/Deco with encrypted login) cannot be read this way: a clear message is returned.
def parse_tplink(text):
    m = re.search(r"var\s+wanPara\s*=\s*new\s+Array\s*\((.*?)\)\s*;", text, re.DOTALL)
    if not m: return None, None
    toks = [x.strip().strip('"\'') for x in m.group(1).split(",")]
    ip = next((x for x in toks[:6] if _IP4.match(x)), None)
    if ip is None: return None, None
    return ip != "0.0.0.0", (None if ip == "0.0.0.0" else ip)  # nosec B104 - compares the router answer, does not bind

def check_tplink(c, http):
    s, t = http.request("/userRpm/StatusRpm.htm", headers={"Referer": http.base + "/userRpm/MenuRpm.htm"})
    if s == 401: raise RouterError("wrong user or password")
    if s != 200: raise RouterError(f"this TP-Link does not offer the classic status page (HTTP {s}); newer models encrypt their login and are not supported")
    up, ip = parse_tplink(t)
    if up is None: raise RouterError("no WAN data in the TP-Link status page (newer models encrypt their login and are not supported)")
    return _res(up, ip, None, "wanPara")

ADAPTERS = {"huawei": check_huawei, "openwrt": check_openwrt, "ddwrt": check_ddwrt, "tplink": check_tplink}

def pin_for(c, host):
    """The stored fingerprint for this address (host:port), or None to learn it. / La huella guardada para esta dirección, o None para aprenderla."""
    p = c.get("tls_pin")
    return p.get("fp") if isinstance(p, dict) and p.get("addr") == f"{host}:{int(c['port'])}" else None

def check(c, host, learn=None):
    """Query the router described by config `c` (type, port, https, user, password, interface) at `host`. Never raises: errors go in the result.
    Over HTTPS the certificate must match c["tls_pin"]; without one, `learn({"addr", "fp"})` is called to keep it."""
    out = {"ok": False, "wan_up": None, "ip": None, "uptime": None, "sys_uptime": None, "detail": "", "error": "", "type": c.get("type"), "host": host, "ts": int(time.time())}
    try:
        if c["type"] not in ADAPTERS: raise RouterError("unknown router type")
        if not host: raise RouterError("no router address (and no default gateway)")
        scheme = "https" if c.get("https") else "http"
        basic = (c["user"], c["password"]) if c["type"] in ("ddwrt", "tplink") else None
        addr = f"{host}:{int(c['port'])}"
        keep = (lambda fp: learn({"addr": addr, "fp": fp})) if learn else None
        http = Http(f"{scheme}://{addr}", basic=basic, pin=pin_for(c, host), learn=keep)
        out.update(ADAPTERS[c["type"]](c, http)); out["ts"] = int(time.time())
    except RouterError as e: out["error"] = str(e)[:200]
    except Exception as e: out["error"] = f"{type(e).__name__}: {e}"[:200]  # noqa: BLE001 - el error queda guardado y se muestra / the error is kept and shown
    return out

def classify_scope(gateway_ok, router):
    """'lan' when the router itself does not answer; 'wan' when it answers and says its internet link is down; otherwise 'internet' (beyond the router / unknown)."""
    if not gateway_ok: return "lan"
    if router and router.get("ok") and router.get("wan_up") is False: return "wan"
    return "internet"
